define([
    'jquery',
    'framework/viewcontroller/PageAbstractController',
    'framework/utils/VariableManager',
    'framework/utils/globals',
    'framework/utils/Logger'
], function($, PageAbstract, VariableManager, Globals, Logger){
    /**
     * Page Constructor
     * @param p_oCourseController : Reference to CourseController
     * @param p_$pageHolder : The HTML element to which the page will get appended
     * @param p_domView : Page HTML View
     * @param p_xmlData : Page XML Data
     * @param p_cssData : Page CSS Data
     * @return instance of Page
     */
    function ClicakbleImages(p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID){
        //Logger.logDebug('ClicakbleImages.CONSTRUCTOR() ');
        PageAbstract.call(this, p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID);
        // ** START - Declare Page variables for individual screens
		this.onPanelShown = this.onPanelShown.bind(this);
        // ** END - Declare Page variables for individual screens
        return this;
    }

    ClicakbleImages.prototype                                   = Object.create(PageAbstract.prototype);
    ClicakbleImages.prototype.constructor                       = ClicakbleImages;
    // ** The constructor and the lines above are mandatory for every page

    /**
     * Function initialize() : gets called after the folowing:
     *      1) populating the view with the required content based on ID mapping,
     *      2) any activity initialization,
     *      3) all images are loaded.
     * This function should be used to read additional parameters from the data XML and do the required customization to the HTML view
     */
    ClicakbleImages.prototype.initialize                        = function(){
        //Logger.logDebug('ClicakbleImages.initialize() ');
        // ** START - Custom Implementation for individual screens
      	this.getComponentByGUID('comp_1').addEventListener('PANEL_SHOWN', this.onPanelShown);
      	this.getActivityByQuestionID('MCQ_1').addEventListener('ACTIVITY_COMPLETE', this.onPanelShown);
    
        // ** END - Custom Implementation for individual screens
       
        PageAbstract.prototype.initialize.call(this, true);
    };


	 ClicakbleImages.prototype.onPanelShown                           = function(e){
	 	this.getComponentByGUID('comp_1').component.reset();
	 	this.resetActivity('MCQ_1');
	 };


    /**
     * Destroys the Page Object
     */
    ClicakbleImages.prototype.destroy                           = function(){
        //Logger.logDebug('ClicakbleImages.destroy() | ');
        // ** START - Custom Implementation for destroying Page variables

        // ** END - Custom Implementation for destroying Page variables
		// ** Calling Super Class "destroy()" function
        PageAbstract.prototype.destroy.call(this);
    };

    return ClicakbleImages;
});