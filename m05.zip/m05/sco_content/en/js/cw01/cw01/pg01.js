define([
    'jquery',
    'framework/viewcontroller/PageAbstractController',
    'framework/utils/VariableManager',
    'framework/utils/globals',
    'framework/utils/Logger'
], function ($, PageAbstract, VariableManager, Globals, Logger) {
    /**
     * Page Constructor
     * @param p_oCourseController : Reference to CourseController
     * @param p_$pageHolder : The HTML element to which the page will get appended
     * @param p_domView : Page HTML View
     * @param p_xmlData : Page XML Data
     * @param p_cssData : Page CSS Data
     * @return instance of Page
     */
    function ClicakbleImages(p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID) {
        //Logger.logDebug('ClicakbleImages.CONSTRUCTOR() ');
        PageAbstract.call(this, p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID);
        // ** START - Declare Page variables for individual screens

        // ** END - Declare Page variables for individual screens
        return this;
    }

    ClicakbleImages.prototype = Object.create(PageAbstract.prototype);
    ClicakbleImages.prototype.constructor = ClicakbleImages;
    // ** The constructor and the lines above are mandatory for every page

    /**
     * Function initialize() : gets called after the folowing:
     *      1) populating the view with the required content based on ID mapping,
     *      2) any activity initialization,
     *      3) all images are loaded.
     * This function should be used to read additional parameters from the data XML and do the required customization to the HTML view
     */
    ClicakbleImages.prototype.initialize = function () {
        //Logger.logDebug('ClicakbleImages.initialize() ');
        // ** START - Custom Implementation for individual screens
        var oScope = this;
        if (VariableManager.getVariable('scenario-jump')) {
            $('#container_navigation').addClass('hide');
            VariableManager.setVariable('scenario-jump', false);
            this.$domView.find('#btn_start').removeClass('hide');
            var $btnStart = this.$domView.find('#btn_start');
            $btnStart.removeClass('hide');
            $btnStart.click(function (e) {
                oScope.navigateNext();
            });
            VariableManager.setVariable('scenario-jump', false);
        }

        $('#tab1_btn').click(function(){
            $('#tab1_container').removeClass('hide');
            $('#tab2_container').addClass('hide');
            $('#tab2_btn').removeClass('selected');
            $('#tab1_btn').addClass('selected');
        });

        $('#tab2_btn').click(function(){
            $('#tab1_container').addClass('hide');
            $('#tab2_container').removeClass('hide');
            $('#tab2_btn').addClass('selected');
            $('#tab1_btn').removeClass('selected');
            $('video')[0].pause();
        });
        // ** END - Custom Implementation for individual screens

        // ** Required call to the Course Controller to remove the preloader



        //var oClickAndReveal = new ClickAndReveal(this.$domView.find('#comp_1'));
        this.dispatchPageLoadedEvent();
        PageAbstract.prototype.initialize.call(this, true);
    };




    /**
     * Destroys the Page Object
     */
    ClicakbleImages.prototype.destroy = function () {
        //Logger.logDebug('ClicakbleImages.destroy() | ');
        // ** START - Custom Implementation for destroying Page variables

        // ** END - Custom Implementation for destroying Page variables
        $('#container_navigation').removeClass('hide');
        // ** Calling Super Class "destroy()" function
        PageAbstract.prototype.destroy.call(this);
    };

    return ClicakbleImages;
});