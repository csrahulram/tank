define([
	'jquery',
	'framework/viewcontroller/PageAbstractController',
	'framework/utils/globals',
	'framework/utils/Logger'
], function($, PageAbstract, Globals, Logger){
	/**
	 * Page Constructor
	 * @param p_oCourseController : Reference to CourseController
	 * @param p_$pageHolder : The HTML element to which the page will get appended
	 * @param p_domView : Page HTML View
	 * @param p_xmlData : Page XML Data
	 * @param p_cssData : Page CSS Data
	 * @return instance of Page
	 */
	function pg09(p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID){
		//Logger.logDebug('pg09.CONSTRUCTOR() ');
		PageAbstract.call(this, p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID);
		// ** START - Declare Page variables for individual screens
		this.openOtherPopup = this.openOtherPopup.bind(this);
		
		// ** END - Declare Page variables for individual screens
		return this;
	}

	pg09.prototype									= Object.create(PageAbstract.prototype);
	pg09.prototype.constructor						= pg09;
	// ** The constructor and the lines above are mandatory for every page
	

	/**
	 * Function initialize() : gets called after the folowing:
	 * 		1) populating the view with the required content based on ID mapping,
	 * 		2) any activity initialization,
	 * 		3) all images are loaded.
	 * This function should be used to read additional parameters from the data XML and do the required customization to the HTML view
	 */
	pg09.prototype.initialize						= function(){
		var oScope = this;
		var oComp = this.getComponentByGUID('comp_1').component;
       	oComp.addEventListener('POPUP_CLOSE', this.openOtherPopup);	
				
		/*
		this.$domView.find('.act-container  #btn_close').click(function(){
			oScope.$domView.find('.act-container').addClass('hide');
		});
		
		this.$domView.find('.btn-container  .btn-recom').click(function(){
			oScope.$domView.find('#MCQ_1_reset').trigger('click');
			oScope.$domView.find('.act-container').removeClass('hide');
		});
			*/
			
			
		PageAbstract.prototype.initialize.call(this, true);
	
	};
		  
	pg09.prototype.openOtherPopup = function(e) {
		var $targetBtn = (e.btnID === "btn_Popup1")?this.$domView.find('#btn_Popup2') : this.$domView.find('#btn_Popup1');
		setTimeout(function(){
			$targetBtn.trigger('click');	
		}, 500);
    };
    

	/**
	 * Destroys the Page Object
	 */
	pg09.prototype.destroy 							= function(){
		//Logger.logDebug('pg09.destroy() | ');
		// ** START - Custom Implementation for destroying Page variables
		// ** END - Custom Implementation for destroying Page variables

		// ** Calling Super Class "destroy()" function
		PageAbstract.prototype.destroy.call(this);
	};

	return pg09;
});