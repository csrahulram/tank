define([
	'jquery',
	'framework/viewcontroller/PageAbstractController',
	'framework/utils/globals',
	'framework/utils/Logger'
], function($, PageAbstract, Globals, Logger){
	/**
	 * Page Constructor
	 * @param p_oCourseController : Reference to CourseController
	 * @param p_$pageHolder : The HTML element to which the page will get appended
	 * @param p_domView : Page HTML View
	 * @param p_xmlData : Page XML Data
	 * @param p_cssData : Page CSS Data
	 * @return instance of Page
	 */
	function ClicakbleImages(p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID){
		//Logger.logDebug('pg09.CONSTRUCTOR() ');
		PageAbstract.call(this, p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID);
		// ** START - Declare Page variables for individual screens
		
		// ** END - Declare Page variables for individual screens
		return this;
	}

	ClicakbleImages.prototype									= Object.create(PageAbstract.prototype);
	// ** The constructor and the lines above are mandatory for every page

	/**
	 * Function initialize() : gets called after the folowing:
	 * 		1) populating the view with the required content based on ID mapping,
	 * 		2) any activity initialization,
	 * 		3) all images are loaded.
	 * This function should be used to read additional parameters from the data XML and do the required customization to the HTML view
	 */

	ClicakbleImages.prototype.initialize						= function(){
		var oScope = this;
		var oAct = this.getActivityByQuestionID('CUSTOM_MMCQ_3');
        oAct.addEventListener('ACTIVITY_COMPLETE', function(){
			$('#btn_reset').removeClass('hide');
        });

		$('#btn_reset').click(function(e){
           oScope.resetActivities(e);
           $('#CUSTOM_MMCQ_1').removeClass('hide');
		   $('#CUSTOM_MMCQ_2').addClass('hide');
		   $('#CUSTOM_MMCQ_3').addClass('hide');
		   $('#btn_reset').addClass('hide');
        });


		$('#tab1_head').click(function(){
			resetTabs();
			$('#tab1_head').addClass('selected');
			$('#tab1_container').removeClass('hide');
		});

		$('#tab2_head').click(function(){
			resetTabs();
			$('#tab2_head').addClass('selected');
			$('#tab2_container').removeClass('hide');
		});

		$('#tab3_head').click(function(){
			resetTabs();
			$('#tab3_head').addClass('selected');
			$('#tab3_container').removeClass('hide');
		});

		function resetTabs(){
			$('#tab1_head').removeClass('selected');
			$('#tab1_container').addClass('hide');
			$('#tab2_head').removeClass('selected');
			$('#tab2_container').addClass('hide');
			$('#tab3_head').removeClass('selected');
			$('#tab3_container').addClass('hide');
			$('#tab1_popup1').addClass('hide');
			$('#tab1_popup2').addClass('hide');
			$('#tab1_popup3').addClass('hide');
			$('#tab1_popup4').addClass('hide');
			$('#tab1_popup_btn1').removeClass('selected');
			$('#tab1_popup_btn2').removeClass('selected');
			$('#tab1_popup_btn3').removeClass('selected');
			$('#tab1_popup_btn4').removeClass('selected');
			$('#btn_reset').trigger('click');
		}
		
		PageAbstract.prototype.initialize.call(this, true);
	};

	ClicakbleImages.prototype.resetActivities = function(e) {
    	var oScope = this,$target = $(e.target),oAct,sID,$elem;
        //console.log(this.aActivities)
    	for (var i=0; i < this.aActivitiesCompleted.length; i++) {
		  	oAct 		= this.aActivitiesCompleted[i];
		  	sID			= oAct.getQuestionID();
		  	$elem		= oScope.$domView.find('#'+ sID);
		  	
		 	oAct.resetScore();
		 	oAct.resetAttemptNumber();
		 	oAct.checkAndResetOptions();
			oAct.hideAnswers();
		  	this.resetActivity(sID);
		  	$elem.addClass('hide');	
		  	i--;
		};
		sID 			= this.aActivities[0].getQuestionID();
		$elem 			= oScope.$domView.find('#'+ sID);
		$elem.removeClass('hide');
		this.actNum = 1;
		this.$domView.find('#act_pg_num').html("Question " + this.actNum + " of 3");
		this.$domView.find('#complete_pop').addClass('hide');
		this.$domView.find('.btn-reset').addClass('hide');
    };

	

	ClicakbleImages.prototype.onActivityComplete 			= function(e){
     	var obj=this.$domView.find('#act_pg_num');
		this.actNum++;
		if(this.actNum<=3){
			obj.html("Question " + this.actNum + " of 3");
		}
		PageAbstract.prototype.onActivityComplete.call(this, e);
     };
	 
    ClicakbleImages.prototype.handleEvents                  = function(e){
        //Logger.logDebug('ClicakbleImages.handleButtonEvents() '+$(e.target).attr('id'));
        e.preventDefault();
        var obj = e.target.getAttribute('target')?e.target:$(e.target).parent()[0];
        var sBtnName    = obj.getAttribute('id'),
            sBtnText    = $(obj).find("div").html();
        sPopupText          = Globals.getElementByID(this.$domView, obj.getAttribute('target'), 'ClicakbleImages.initialize()').html();
        //To add call back take the returned obj below and add .setcallback call to it
        this.openPopup('popup_close', sBtnText, sPopupText, $(e.target));
    };

	

	/**
	 * Destroys the Page Object
	 */
	ClicakbleImages.prototype.destroy 							= function(){
		//Logger.logDebug('pg09.destroy() | ');
		// ** START - Custom Implementation for destroying Page variables
		this.$domView.find('#btn_Popup1').off();
		// ** END - Custom Implementation for destroying Page variables

		// ** Calling Super Class "destroy()" function
		PageAbstract.prototype.destroy.call(this);
	};

	return ClicakbleImages;
});