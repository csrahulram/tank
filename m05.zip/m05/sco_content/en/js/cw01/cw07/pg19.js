define([
    'jquery',
    'framework/viewcontroller/PageAbstractController',
    'framework/utils/globals',
    'framework/utils/Logger',
    'framework/component/Menu'

], function($, PageAbstract, Globals, Logger, MenuComponent) {
    /** 
     * Page Constructor 
     * @param p_oCourseController : Reference to CourseController 
     * @param p_$pageHolder : The HTML element to which the page will get appended 
     * @param p_domView : Page HTML View 
     * @param p_xmlData : Page XML Data 
     * @param p_cssData : Page CSS Data 
     * @return instance of Page 
     */
    function pg06(p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID) {
		//Logger.logDebug('pg06.CONSTRUCTOR() '); 
        PageAbstract.call(this, p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID);
		// ** START - Declare Page variables for individual screens 
		this.actNum = 1;
		this.resetActivities		= this.resetActivities.bind(this);
		this.showRestart = this.showRestart.bind(this);
		this.onPopupShow = this.onPopupShow.bind(this);
        // ** END - Declare Page variables for individual screens
        return this;
    }

    pg06.prototype = Object.create(PageAbstract.prototype);
    pg06.prototype.constructor = pg06;
    // ** The constructor and the lines above are mandatory for every page

    /** 
     * Function initialize() : gets called after the following: 
     * 1) populating the view with the required content based on ID mapping, 
     * 2) any activity initialization, 
     * 3) all images are loaded. 
     * This function should be used to read additional parameters from the data XML and do the required customization to the HTML view 
     */
    pg06.prototype.initialize = function() {
       var oScope=this;
       
        this.getComponentByGUID('comp_1').component.addEventListener('COMPONENT_INTERACTION_COMPLETE', this.onPopupShow);
	   var elem = document.getElementById("btnReset");
		this.$domView.find('.cnr-btn').click(function(e){
				this.$domView.find('#complete_pop').removeClass('hide');
				elem.click(elem);
		});
		this.$domView.find('#btnReset').click(function(e){
			oScope.resetActivities(e);
		});
		var oAct = this.getActivityByQuestionID('MCQ_2');
        oAct.addEventListener('ACTIVITY_COMPLETE', this.showRestart);
       
       
       	$(document).ready(function() {                                 
                                setTimeout(function() { 
                                                $("#email_1").fadeOut(2000);
                                                                setTimeout(function() { $("#btn_Popup1").fadeIn(2000);},1000);
                                                
                                                }, 2000);
                                });


       
	   PageAbstract.prototype.initialize.call(this, true);
    };

  
 pg06.prototype.onPopupShow      = function(e){	
		var oScope 	= this;
		
		if(e.target.isComplete()){
			if($('#btn_Popup2').hasClass('disabled')){
				
				$('#btn_Popup2').removeClass('disabled');				
			}
			else{
				return;
			}
		}
		
	};
       
    pg06.prototype.resetActivities = function(e) {
    	var oScope = this,$target = $(e.target),oAct,sID,$elem;
    	for (var i=0; i < this.aActivitiesCompleted.length; i++) {
		  	oAct 		= this.aActivitiesCompleted[i];
		  	sID			= oAct.getQuestionID();
		  	$elem		= oScope.$domView.find('#'+ sID);
		  	
		 	oAct.resetScore();
		 	oAct.resetAttemptNumber();
		 	oAct.checkAndResetOptions();
			oAct.hideAnswers();
		  	this.resetActivity(sID);

		  	$elem.addClass('hide');	
		  	i--;
		};

		sID 			= this.aActivities[0].getQuestionID();
		$elem 			= oScope.$domView.find('#'+ sID);
		$elem.removeClass('hide');
		this.actNum = 1;
		this.$domView.find('#act_pg_num').html("Question " + this.actNum + " of 2");
		this.$domView.find('#complete_pop').addClass('hide');
    };
    
   pg06.prototype.showRestart = function() {
		this.$domView.find('#complete_pop').removeClass('hide');
    };

   	pg06.prototype.onActivityComplete 			= function(e){
     	var obj=this.$domView.find('#act_pg_num');
		this.actNum++;
		if(this.actNum<=2){
			obj.html("Question " + this.actNum + " of 2");
		}
		PageAbstract.prototype.onActivityComplete.call(this, e);
     };
     
     pg06.prototype.destroy = function() {
        //Logger.logDebug('pg06.destroy() | ');
        // ** START - Custom Implementation for destroying Page variables
        // ** END - Custom Implementation for destroying Page variables

        // ** Calling Super Class "destroy()" function
        PageAbstract.prototype.destroy.call(this);
    };
	
 
	

    return pg06;
});