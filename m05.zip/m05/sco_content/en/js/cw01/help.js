define([
    'jquery',
    'framework/viewcontroller/PageAbstractController',
    'framework/utils/globals',
    'framework/component/Tabs',
    'framework/utils/Logger',
    'framework/utils/VariableManager',
], function($, PageAbstract, Globals, TabComponent, Logger,VariableManager) {
    /**
     * Page Constructor
     * @param p_oCourseController : Reference to CourseController
     * @param p_$pageHolder : The HTML element to which the page will get appended
     * @param p_domView : Page HTML View
     * @param p_xmlData : Page XML Data
     * @param p_cssData : Page CSS Data
     * @return instance of Page
     */
    function Help(p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID) {
        Logger.logDebug('Help.CONSTRUCTOR()  : ');
        PageAbstract.call(this, p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID);
        // ** START - Declare Page variables for individual screens
    	this.showNextPage = this.showNextPage.bind(this);
    	this.showPrevPage = this.showPrevPage.bind(this);
        // ** END - Declare Page variables for individual screens
        return this;
    }

    Help.prototype = Object.create(PageAbstract.prototype);
    Help.prototype.constructor = Help;
    // ** The constructor and the lines above are mandatory for every page

    /**
     * Function initialize() : gets called after the folowing:
     *      1) populating the view with the required content based on ID mapping,
     *      2) any activity initialization,
     *      3) all images are loaded.
     * This function should be used to read additional parameters from the data XML and do the required customization to the HTML view
     */
    Help.prototype.initialize = function() {
        // START - Custom Implementation for individual screens
        var oScope = this;
    	this.$domView.find('.btn-cont').click(function(e){
    		if($(this).hasClass('disabled'))return;
    		oScope.showNextPage($(this));
    	});
    	this.$domView.find('.btn-prev').click(function(e){
    		if($(this).hasClass('disabled'))return;
    		oScope.showPrevPage($(this));
    	});
        // END - Custom Implementation for individual screens
        PageAbstract.prototype.initialize.call(this, true);
    };
   
  
    Help.prototype.showNextPage = function($btn) {
    	var $page 		= $btn.parent().find('.page');
    	var $selected 	= $btn.parent().find('.page.selected');
    	var $nextPage	= $selected.next('.page');
    	var $prev 		= $btn.parent().find('.btn-prev');	
    	
    	$selected.removeClass('selected');
    	
    	$page.addClass('hide');
    	$nextPage.removeClass('hide').addClass('selected');
    	
    	if(!$nextPage.next('.page').length){
    		$btn.addClass('disabled');
    	}
    	$prev.removeClass('disabled');
    };
    
    Help.prototype.showPrevPage = function($btn) {
    	var $page 		= $btn.parent().find('.page');
    	var $selected 	= $btn.parent().find('.page.selected');
    	var $prevPage	= $selected.prev('.page');
    	var $cont 		= $btn.parent().find('.btn-cont');	
    	
    	$selected.removeClass('selected');
    	
    	$page.addClass('hide');
    	$prevPage.removeClass('hide').addClass('selected');
    	
    	if(!$prevPage.prev('.page').length){
    		$btn.addClass('disabled');
    	}
			$cont.removeClass('disabled');
    };
    /**
     * Destroys the Page Object
     */
    Help.prototype.destroy = function() {
        // ** START - Custom Implementation for destroying Page variables

        // ** END - Custom Implementation for destroying Page variables

        // ** Calling Super Class "destroy()" function
        PageAbstract.prototype.destroy.call(this);
    };

    return Help;
});
