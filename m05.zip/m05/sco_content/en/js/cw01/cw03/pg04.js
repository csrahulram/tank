define([
	'jquery',
	'framework/viewcontroller/PageAbstractController',
	'framework/utils/VariableManager',
	'framework/utils/globals',
	'framework/utils/Logger'
], function($, PageAbstract, VariableManager, Globals, Logger){
	/**
	 * Page Constructor
	 * @param p_oCourseController : Reference to CourseController
	 * @param p_$pageHolder : The HTML element to which the page will get appended
	 * @param p_domView : Page HTML View
	 * @param p_xmlData : Page XML Data
	 * @param p_cssData : Page CSS Data
	 * @return instance of Page
	 */
	function pg04(p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID){
		//Logger.logDebug('pg04.CONSTRUCTOR() ');
		PageAbstract.call(this, p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID);
		// ** START - Declare Page variables for individual screens

		// ** END - Declare Page variables for individual screens
		return this;
	}

	pg04.prototype									= Object.create(PageAbstract.prototype);
	pg04.prototype.constructor						= pg04;
	// ** The constructor and the lines above are mandatory for every page

	/**
	 * Function initialize() : gets called after the folowing:
	 * 		1) populating the view with the required content based on ID mapping,
	 * 		2) any activity initialization,
	 * 		3) all images are loaded.
	 * This function should be used to read additional parameters from the data XML and do the required customization to the HTML view
	 */
	pg04.prototype.initialize						= function(){
		var oScope = this;

         var oAct = this.getActivityByQuestionID('MCQ_1');
        oAct.addEventListener('ACTIVITY_COMPLETE', this.showRestart);
        $('#btn_text').click(function(e){
            $('#popup_tab1').trigger('click');
        	oScope.resartQuiz();
        });

        $('#close_btn').click(function(){
            $('#main_popup').addClass('hide');
            $('#btn_text').removeClass('selected');
            $('#btn1_popup').addClass('hide');
            $('#btn2_popup').addClass('hide');
            $('#btn3_popup').addClass('hide');
        });

        $('#popup_tab1').click(function(){
            $('#activity_container').addClass('hide');
            $('#popup_tab1').addClass('selected');
            $('#popup_tab2').removeClass('selected');
        });

        $('#popup_tab2').click(function(){
            $('#activity_container').removeClass('hide');
            $('#popup_tab1').removeClass('selected');
            $('#popup_tab2').addClass('selected');
        });

        

        
		PageAbstract.prototype.initialize.call(this, true);

	};

    pg04.prototype.resartQuiz = function() {
    	var i,act;
    
    	for (i=0; i < this.aActivitiesCompleted.length; i++) {
    		act = this.aActivitiesCompleted[i];
		  	act.getView().addClass('hide');
		  	this.resetActivity(act.getQuestionID());
		  	act.resetAttemptNumber();
		  	act.resetScore();
		  	act.checkAndResetOptions();
		  	i--;
		};
		this.$domView.find('#MCQ_1').removeClass('hide');
		this.$domView.find('.btn-reset').addClass('hide');
    };

    pg04.prototype.showRestart = function() {
		$('.btn-reset').removeClass('hide');
    };
	/**
	 * Destroys the Page Object
	 */
	pg04.prototype.destroy 							= function(){
		//Logger.logDebug('pg04.destroy() | ');
		// ** START - Custom Implementation for destroying Page variables
			
		// ** END - Custom Implementation for destroying Page variables

		// ** Calling Super Class "destroy()" function
		PageAbstract.prototype.destroy.call(this);
	};

	return pg04;
});