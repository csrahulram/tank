define([
    'jquery',
    'framework/viewcontroller/PageAbstractController',
    'framework/utils/globals',
    'framework/utils/Logger',
    'framework/component/Menu'

], function($, PageAbstract, Globals, Logger, MenuComponent) {
    /** 
     * Page Constructor 
     * @param p_oCourseController : Reference to CourseController 
     * @param p_$pageHolder : The HTML element to which the page will get appended 
     * @param p_domView : Page HTML View 
     * @param p_xmlData : Page XML Data 
     * @param p_cssData : Page CSS Data 
     * @return instance of Page 
     */
    function pg06(p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID) {
		//Logger.logDebug('pg06.CONSTRUCTOR() '); 
        PageAbstract.call(this, p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID);
		// ** START - Declare Page variables for individual screens 
		this.data ={
			'multiactivity_1':{
				deps:['MCQ_1','MCQ_2','MCQ_3'],
				show:['MCQ_4','MCQ_5','MCQ_6'],
				nextmultiact:'multiactivity_2'
			},
			'multiactivity_2':{
				deps:['MCQ_4','MCQ_5','MCQ_6'],
				show:['MCQ_7','MCQ_8','MCQ_9'],
				nextmultiact:'multiactivity_3'
			},
			'multiactivity_3':{
				deps:['MCQ_7','MCQ_8','MCQ_9'],
				show:['MCQ_10','MCQ_11','MCQ_12'],
				nextmultiact:'multiactivity_4'
			},
			'multiactivity_4':{
				deps:['MCQ_10','MCQ_11','MCQ_12'],
				show:['MCQ_13','MCQ_14','MCQ_15'],
				nextmultiact:'multiactivity_5'
			},
			'multiactivity_5':{
				deps:['MCQ_13','MCQ_14','MCQ_15'],
				show:['MCQ_16','MCQ_17','MCQ_18'],
				nextmultiact:'multiactivity_6'
			},
			'multiactivity_6':{
				deps:['MCQ_16','MCQ_17','MCQ_18'],
				show:['MCQ_19','MCQ_20','MCQ_21'],
				nextmultiact:'multiactivity_7'
			},
			'multiactivity_7':{
				deps:['MCQ_19','MCQ_20','MCQ_21'],
				show:['MCQ_22','MCQ_23','MCQ_24'],
				nextmultiact:'multiactivity_8'
			},
			'multiactivity_8':{
				deps:['MCQ_22','MCQ_23','MCQ_24'],
				show:['MCQ_25','MCQ_26','MCQ_27'],
				nextmultiact:'multiactivity_9'
			},
			'multiactivity_9':{
				deps:['MCQ_25','MCQ_26','MCQ_27'],
				show:[],
				nextmultiact:null
			}
		};
		
		this.resetAllActivities		= this.resetAllActivities.bind(this);
        // ** END - Declare Page variables for individual screens
        return this;
    }

    pg06.prototype = Object.create(PageAbstract.prototype);
    pg06.prototype.constructor = pg06;
    // ** The constructor and the lines above are mandatory for every page

    /** 
     * Function initialize() : gets called after the folowing: 
     * 1) populating the view with the required content based on ID mapping, 
     * 2) any activity initialization, 
     * 3) all images are loaded. 
     * This function should be used to read additional parameters from the data XML and do the required customization to the HTML view 
     */
    pg06.prototype.initialize = function() {
       var oScope=this;
		
		this.$domView.find('#btnReset').click(function(e){
			oScope.resetAllActivities();
			oScope.setActivity(null);
			$(this).addClass('hide');
		});
		
		this.resetAllActivities();
		this.setActivity(null);
		
        PageAbstract.prototype.initialize.call(this, true);
    };


   pg06.prototype.resetAllActivities = function() {
	
		
		for (var i = 0; i < this.aActivitiesCompleted.length; i++) {
			var oAct = this.aActivitiesCompleted[i];
			oAct.resetScore();
			oAct.resetOptions();
			oAct.resetAttemptNumber();
			if(oAct.getQuestionID().indexOf('MMCQ') === -1){
				oAct.getView().addClass('hide');
			}
			this.resetActivity(oAct.getQuestionID());
			i--;
		};
		
		
		
	
		
		// for (var i = 0; i < this.aComponents.length; i++) {
			// var oComp = this.aComponents[i];
			// if (oComp.getComponentID() !== "comp_1") {
				// oComp.reset();
			// }
		// };
	};
    
   
   	pg06.prototype.onActivityComplete 			= function(e){
     	id = e.target.getQuestionID();
     	if(id.indexOf('multiactivity') !== -1){
     		this.setActivity(id);
     	}
		     	
     	PageAbstract.prototype.onActivityComplete.call(this, e);
     };
     
   	pg06.prototype.setActivity 			= function(p_oActID){
   		var data = this.data[p_oActID];
	  	if(data){
		  		var nextMultiActID = data.nextmultiact, id;
		   	if(nextMultiActID){
		   		

		   		
				var currentID = parseInt(nextMultiActID.slice(-1)); 

				//alert("nextMultiActID>>"+currentID)

		   		var prevId=currentID-1;

		   		this.$domView.find("#Act"+prevId+"_txt1").addClass('hide');
		   		this.$domView.find("#Act"+prevId+"_txt2").addClass('hide'); 

		   		this.$domView.find("#Act"+currentID+"_txt1").removeClass('hide');
		   		this.$domView.find("#Act"+currentID+"_txt2").removeClass('hide'); 

	   			for (var i=0; i < data.deps.length; i++) {
				 	id 		= data.deps[i],
				 	act 	= this.getActivityByQuestionID(id);
				 	act.getView().addClass('hide');
			   	}
			   	
	   			for (var i=0; i < data.show.length; i++) {
				 	id 		= data.show[i],
				 	act 	= this.getActivityByQuestionID(id);
				 	act.getView().removeClass('hide');
			   	}
			   	
			   	this.getActivityByQuestionID(p_oActID).getView().addClass('hide');
			   	this.getActivityByQuestionID(nextMultiActID).getView().removeClass('hide');
		   	}else{
		   		this.getActivityByQuestionID(p_oActID).getView().addClass('hide');
		   		this.$domView.find('#btnReset').removeClass('hide');
		   	}
   		}else{
	   		data =  this.data['multiactivity_1'];
   			for (var i=0; i < data.deps.length; i++) {
			 	id 		= data.deps[i],
			 	act 	= this.getActivityByQuestionID(id);
			 	act.getView().removeClass('hide');
		   	}
		   	this.$domView.find("#Act9_txt1").addClass('hide');
		   	this.$domView.find("#Act9_txt2").addClass('hide'); 

	   		this.$domView.find("#Act1_txt1").removeClass('hide');
	   		this.$domView.find("#Act1_txt2").removeClass('hide'); 

		   	 this.getActivityByQuestionID('multiactivity_1').getView().removeClass('hide');
   		}
   		
   	};
     
     
     pg06.prototype.destroy = function() {
        //Logger.logDebug('pg06.destroy() | ');
        // ** START - Custom Implementation for destroying Page variables
        // ** END - Custom Implementation for destroying Page variables

        // ** Calling Super Class "destroy()" function
        PageAbstract.prototype.destroy.call(this);
    };
	
 
	

    return pg06;
});