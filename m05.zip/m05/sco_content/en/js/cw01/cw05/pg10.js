define([
    'jquery',
    'framework/viewcontroller/PageAbstractController',
    'framework/utils/globals',
    'framework/utils/VariableManager',
    'framework/utils/Logger'
], function($, PageAbstract, Globals, VariableManager, Logger){
    /**
     * Page Constructor
     * @param p_oCourseController : Reference to CourseController
     * @param p_$pageHolder : The HTML element to which the page will get appended
     * @param p_domView : Page HTML View
     * @param p_xmlData : Page XML Data
     * @param p_cssData : Page CSS Data
     * @return instance of Page
     */
    function ClicakbleImages(p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID){
        //Logger.logDebug('ClicakbleImages.CONSTRUCTOR() ');
        PageAbstract.call(this, p_oCourseController, p_$pageHolder, p_domView, p_xmlData, p_cssData, p_sGUID);
       	this.onBtnClick = this.onBtnClick.bind(this);
        // ** START - Declare Page variables for individual screens

        // ** END - Declare Page variables for individual screens
        return this;
    }

    ClicakbleImages.prototype                                   = Object.create(PageAbstract.prototype);
    ClicakbleImages.prototype.constructor                       = ClicakbleImages;
    // ** The constructor and the lines above are mandatory for every page

    /**
     * Function initialize() : gets called after the folowing:
     *      1) populating the view with the required content based on ID mapping,
     *      2) any activity initialization,
     *      3) all images are loaded.
     * This function should be used to read additional parameters from the data XML and do the required customization to the HTML view
     */
    ClicakbleImages.prototype.initialize                        = function(){
	       
     	this.aComponents[0].addEventListener('btn_click',this.onBtnClick);
		PageAbstract.prototype.initialize.call(this, true);
    };

	ClicakbleImages.prototype.onBtnClick = function(e) {
    	var oScope 		= this;
    	var sBtn 		= e.clicktarget;
    	var sPopupID 	= '#popup_'+sBtn.split('_')[1];
    	
    	var aStyle = ['col5 row6 l7 t5', 'col5 row6 l7 t5','col5 row4 l7 t5', 'col5 row4 l2 t5', 'col5 row4 l2 t5', 'col5 row5 l2 t5'];
    	var curStyle = aStyle[parseInt(sBtn.split('_')[1]) - 1];
    	
    	 this.openPopup('popup_close', '',this.$domView.find(sPopupID),this.$domView, curStyle, function(){
    	 	oScope.aComponents[0].gotoAndStop(252);
    	 });
    	
    };
    
    
    /**
     * Destroys the Page Object
     */
    ClicakbleImages.prototype.destroy                           = function(){
        //Logger.logDebug('ClicakbleImages.destroy() | ');
        // ** START - Custom Implementation for destroying Page variables

         this.aComponents[0].removeEventListener('btn_click',this.onBtnClick);
        // ** END - Custom Implementation for destroying Page variables

        // ** Calling Super Class "destroy()" function
        PageAbstract.prototype.destroy.call(this);
    };

    return ClicakbleImages;
});