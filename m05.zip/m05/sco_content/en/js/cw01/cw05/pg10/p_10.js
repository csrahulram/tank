var animate = function(){var cjs = createjs;var img = {};var ss 	= {};var lib = function(){return this;};lib.images = function(_img){img = _img;};

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 870,
	height: 318,
	fps: 24,
	color: "#FFFFFF",
	webfonts: {},
	manifest: [
		{src:"images/Bitmap1.png", id:"Bitmap1"},
		{src:"images/Bitmap2.png", id:"Bitmap2"},
		{src:"images/Bitmap3.png", id:"Bitmap3"},
		{src:"images/Bitmap4.png", id:"Bitmap4"},
		{src:"images/Bitmap5.png", id:"Bitmap5"},
		{src:"images/Bitmap6.png", id:"Bitmap6"},
		{src:"images/screen9_bg.jpg", id:"screen9_bg"}
	]
};



lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.Bitmap1 = function() {
	this.initialize(img.Bitmap1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,135,184);


(lib.Bitmap2 = function() {
	this.initialize(img.Bitmap2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,123,183);


(lib.Bitmap3 = function() {
	this.initialize(img.Bitmap3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,213,91);


(lib.Bitmap4 = function() {
	this.initialize(img.Bitmap4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,123,183);


(lib.Bitmap5 = function() {
	this.initialize(img.Bitmap5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,213,91);


(lib.Bitmap6 = function() {
	this.initialize(img.Bitmap6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,135,184);


(lib.screen9_bg = function() {
	this.initialize(img.screen9_bg);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,430,324);


(lib.gr_bg1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("A/cYEMAAAgwHMA+5AAAMAAAAwHg");
	mask.setTransform(214.8,154);

	// Layer 1
	this.instance = new lib.screen9_bg();

	this.instance.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(13.5,0,402.7,308);


(lib.mc_btn_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{up:0,over:1,down:2,disabled:3});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}
	this.frame_1 = function() {
		/* stop();*/
	}
	this.frame_2 = function() {
		/* stop();*/
	}
	this.frame_3 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAVBUQgFgDgCgEQgDgFAAgFQAAgNALgGQALgHASAAIAAgBIgBgFQAAgDgDgCQgEgCgFAAIgKACIgJADIgDgLQADgCAHgCQAGgCAIAAQALAAAHAEQAFAEADAHQADAGgBAIIAAAYIABAJIAAAIIgPAAIgBgIIgBAAQgDAEgFADQgFACgHAAQgGAAgFgDgAAoA1QgFABgEADQgDADAAAFQAAAFADADQADACAEAAQAFAAAEgDQADgDABgDIAAgCIABgCIAAgKIgMABgABmBVQgEgCgDgCQgCgDgBgFQgCgEgBgHIAAggIgKAAIAAgNIAKAAIgBgMIARgFIABARIAQgBIAAANIgQAAIAAAfQAAAGADADQACADAFAAIAEAAIACgBIABANIgFACIgHAAQgFAAgEgBgACKAPIASgBIAFBEIgSABgAgTBRIAAgLIAAAAIgFAFQgDACgEACQgFABgGgBQgGAAgGgEQgEgDgCgHQgEgHACgLIAFgoIARACIgFAlQgBAIACAGQADAFAGABQAGABADgDQAFgCAAgDIACgDIAAgDIAGgoIAPACIgFAvIAAALIgBAJgADABOQgIgEgGgHQgFgIAAgLQgBgLAEgJQAEgIAHgFQAIgFAKAAQALgBAHAEQAJAEAEAHQAFAIAAAKQABANgEAIQgFAJgHAEQgIAEgJABIgCAAQgJAAgGgDgADNAWQgFABgEADQgDAEgBAFQgCAGABAFQAAAHACAFQADAFAEADQAEACAFAAQAFAAADgDQAEgEABgFQACgFgBgHQAAgFgCgGQgBgFgFgDQgDgDgFAAIgCAAgAhiBIIAJhhIASACIgKBhgAD9ASIgDgKIgBgIIAPgCIACAJQACgEACgDQACgBAFgCIAJgEQAGgBAGADQAGACAFADQAEAGABALIAGAoIgRACIgFgmQgBgHgEgEQgEgFgHABQgFABgDADQgCAEgBAEIAAADIAAADIAGAnIgSADgAiHA+IABgIIgBAAQgEADgFABQgGABgGgBQgHgCgDgEQgFgEgCgFQAAgFABgFQADgNAMgDQAMgEASAFIABgBIAAgFQAAgDgDgDQgBgDgHgBQgFgBgFAAQgFAAgEABIAAgJQAFgCAGAAQAGAAAJACQAKADAFAEQAFAFAAAHQABAGgCAIIgGAXIgCAJIgBAIgAiWAdQgDABgCAFQgBAFACADQACADAEABQAFABAEgBQAEgCADgEIAAgBIABgCIACgJIgLgCIgCAAQgEAAgEACgAjgAmIgFhGIASAFIABAiIAAAJIAAAJIAAAAIAEgIIAFgHIAUgcIARAFIgsA4gAk/gBIAnhVIAyAXIgGANIgigQIgLAWIAhAPIgGANIghgPIgLAZIAkAPIgGANgACLACQgCgCgBgCQAAgEACgDQADgCAEgBQAEAAADACQACADABAEQAAADgCABQgCADgFABQgEAAgDgDg");
	this.shape.setTransform(94,48.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAVBUQgFgDgCgEQgDgFAAgFQAAgNALgGQALgHASAAIAAgBIgBgFQAAgDgDgCQgEgCgFAAIgKACIgJADIgDgLQADgCAHgCQAGgCAIAAQALAAAHAEQAFAEADAHQADAGgBAIIAAAYIABAJIAAAIIgPAAIgBgIIgBAAQgDAEgFADQgFACgHAAQgGAAgFgDgAAoA1QgFABgEADQgDADAAAFQAAAFADADQADACAEAAQAFAAAEgDQADgDABgDIAAgCIABgCIAAgKIgMABgABmBVQgEgCgDgCQgCgDgBgFQgCgEgBgHIAAggIgKAAIAAgNIAKAAIgBgMIARgFIABARIAQgBIAAANIgQAAIAAAfQAAAGADADQACADAFAAIAEAAIACgBIABANIgFACIgHAAQgFAAgEgBgACKAPIASgBIAFBEIgSABgAgTBRIAAgLIAAAAIgFAFQgDACgEACQgFABgGgBQgGAAgGgEQgEgDgCgHQgEgHACgLIAFgoIARACIgFAlQgBAIACAGQADAFAGABQAGABADgDQAFgCAAgDIACgDIAAgDIAGgoIAPACIgFAvIAAALIgBAJgADABOQgIgEgGgHQgFgIAAgLQgBgLAEgJQAEgIAHgFQAIgFAKAAQALgBAHAEQAJAEAEAHQAFAIAAAKQABANgEAIQgFAJgHAEQgIAEgJABIgCAAQgJAAgGgDgADNAWQgFABgEADQgDAEgBAFQgCAGABAFQAAAHACAFQADAFAEADQAEACAFAAQAFAAADgDQAEgEABgFQACgFgBgHQAAgFgCgGQgBgFgFgDQgDgDgFAAIgCAAgAhiBIIAJhhIASACIgKBhgAD9ASIgDgKIgBgIIAPgCIACAJQACgEACgDQACgBAFgCIAJgEQAGgBAGADQAGACAFADQAEAGABALIAGAoIgRACIgFgmQgBgHgEgEQgEgFgHABQgFABgDADQgCAEgBAEIAAADIAAADIAGAnIgSADgAiHA+IABgIIgBAAQgEADgFABQgGABgGgBQgHgCgDgEQgFgEgCgFQAAgFABgFQADgNAMgDQAMgEASAFIABgBIAAgFQAAgDgDgDQgBgDgHgBQgFgBgFAAQgFAAgEABIAAgJQAFgCAGAAQAGAAAJACQAKADAFAEQAFAFAAAHQABAGgCAIIgGAXIgCAJIgBAIgAiWAdQgDABgCAFQgBAFACADQACADAEABQAFABAEgBQAEgCADgEIAAgBIABgCIACgJIgLgCIgCAAQgEAAgEACgAjgAmIgFhGIASAFIABAiIAAAJIAAAJIAAAAIAEgIIAFgHIAUgcIARAFIgsA4gAk/gBIAnhVIAyAXIgGANIgigQIgLAWIAhAPIgGANIghgPIgLAZIAkAPIgGANgACLACQgCgCgBgCQAAgEACgDQADgCAEgBQAEAAADACQACADABAEQAAADgCABQgCADgFABQgEAAgDgDg");
	this.shape_1.setTransform(94,48.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).wait(2));

	// fill
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#406AB2","#1E3351"],[0.004,1],-18.6,12.8,84,-28.7).s().p("AADGfIgWAAQkygFj4iPIgggTQh2hJhphpQhthrhKh7IC7jUID0gqQAqBGBABAQA1A1A9AoIAfATQCKBQCoAGIAbABIAHAAQCpgCCMhKIAegSQBHgrA+g+QA4g4Aog9ICtDYIAIACID8AeQhKB1hoBmQhsBth6BKIggASQj5CNk0ADIgMAAg");
	this.shape_2.setTransform(101.2,41.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#E4950E","#673F07"],[0.004,1],-18.6,12.8,84,-28.7).s().p("AADGfIgWAAQkygFj4iPIgggTQh2hJhphpQhthrhKh7IC7jUID0gqQAqBGBABAQA1A1A9AoIAfATQCKBQCoAGIAbABIAHAAQCpgCCMhKIAegSQBHgrA+g+QA4g4Aog9ICtDYIAIACID8AeQhKB1hoBmQhsBth6BKIggASQj5CNk0ADIgMAAg");
	this.shape_3.setTransform(101.2,41.6);

	this.instance = new lib.Bitmap3();
	this.instance.setTransform(-4.7,-4.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,202.4,83.2);


(lib.mc_btn_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"up":0,"over":1,"down":2,"disabled":3});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}
	this.frame_1 = function() {
		/* stop();*/
	}
	this.frame_2 = function() {
		/* stop();*/
	}
	this.frame_3 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer 8
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAbDTQgHgEgDgGQgEgGgDgGIgCgNQAAgHABgEIANgBIAAAJQAAAFACAGQACAGACADQAEAEAFABQAFABAHgCIAFgCIAAAAQgFgCgEgEQgEgEgCgGQgCgIABgIQADgIAFgFQAGgGAJgDQALgDAJABQAJACAHAFQAFAFADAIQADAIgCAFQgCAGgDAEIAJgDIAFAPIgIACIgLADIgkAMQgKADgJAAIgCAAQgHAAgFgDgABECeQgGABgEADQgEAEgCAEQgBAFABAFQACAEAEADQAEADAFAAIADAAIACgBIALgEIADgBIACgBQADgDADgEQACgEgCgGQgDgHgGgCIgIgBQgEAAgFACgAAaB+IAkgNQAHgCADgFQAEgEgCgHQgCgFgDgCQgFgCgEAAIgCAAIgEABIglAOIgGgRIAtgQIAKgEIAJgDIAFAOIgJAEIAAABIAHACIAGAFQADAEACAFQACAGAAAGQgCAGgEAFQgFAGgKAEIgmANgAgBA1IA8gcIAHAQIg+AcgAgIAkIgDgHQgDgEAAgEIABgIQABgDAEgEIAIgGIAcgMIgEgJIALgFIAFAJIAMgGIALANIgQAIIAHAMIgLAGIgHgPIgbAOQgGACgCADQgBAEABAEIADAEIABACIgJAGIgEgEgABNAjQgDgCgDgEQAAgEAAgDQACgEAEgBQAEgCADABQADACACAEQABAEgBADQgBADgEACIgEABIgDAAgAgdgNQgGgDgFgIIgEgLQgCgFAAgEIAMgEIABAJIAEAIQADAFADABQADABADgCQADgBAAgEQACgDgDgGQgCgKACgHQACgHAFgCQAFgEAEAAQAGAAAGAEQAFADAFAHIAEAJIABAIIgMAEIAAgGQgCgFgCgDQgCgEgDgBQgDgBgDACQgBABAAADIAAALQABAJgBAHQAAAGgHAEQgFADgGAAQgGAAgFgEgAg+hCIgJgKQgFgJgBgJQgBgKAFgHQAEgIAJgFQAIgGAJgBQAJgBAIAEQAIADAHAJQAEAHAAAHQABAGgCAFQgDAGgEAEIgJAIIgDACIgDABIgYgmQgFADgDAFQgBAEABAFIAEAJIAGAJIAHAGIgJAJIgIgIgAglh1IgHACIAQAaIAFgFQADgDABgEQAAgFgCgEQgEgFgDgBIgGgBIgDAAgAhyiDIA8g1IgRgUIALgJIAuA1IgLAKIgSgVIg7A1g");
	this.shape.setTransform(75.3,78.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAbDTQgHgEgDgGQgEgGgDgGIgCgNQAAgHABgEIANgBIAAAJQAAAFACAGQACAGACADQAEAEAFABQAFABAHgCIAFgCIAAAAQgFgCgEgEQgEgEgCgGQgCgIABgIQADgIAFgFQAGgGAJgDQALgDAJABQAJACAHAFQAFAFADAIQADAIgCAFQgCAGgDAEIAJgDIAFAPIgIACIgLADIgkAMQgKADgJAAIgCAAQgHAAgFgDgABECeQgGABgEADQgEAEgCAEQgBAFABAFQACAEAEADQAEADAFAAIADAAIACgBIALgEIADgBIACgBQADgDADgEQACgEgCgGQgDgHgGgCIgIgBQgEAAgFACgAAaB+IAkgNQAHgCADgFQAEgEgCgHQgCgFgDgCQgFgCgEAAIgCAAIgEABIglAOIgGgRIAtgQIAKgEIAJgDIAFAOIgJAEIAAABIAHACIAGAFQADAEACAFQACAGAAAGQgCAGgEAFQgFAGgKAEIgmANgAgBA1IA8gcIAHAQIg+AcgAgIAkIgDgHQgDgEAAgEIABgIQABgDAEgEIAIgGIAcgMIgEgJIALgFIAFAJIAMgGIALANIgQAIIAHAMIgLAGIgHgPIgbAOQgGACgCADQgBAEABAEIADAEIABACIgJAGIgEgEgABNAjQgDgCgDgEQAAgEAAgDQACgEAEgBQAEgCADABQADACACAEQABAEgBADQgBADgEACIgEABIgDAAgAgdgNQgGgDgFgIIgEgLQgCgFAAgEIAMgEIABAJIAEAIQADAFADABQADABADgCQADgBAAgEQACgDgDgGQgCgKACgHQACgHAFgCQAFgEAEAAQAGAAAGAEQAFADAFAHIAEAJIABAIIgMAEIAAgGQgCgFgCgDQgCgEgDgBQgDgBgDACQgBABAAADIAAALQABAJgBAHQAAAGgHAEQgFADgGAAQgGAAgFgEgAg+hCIgJgKQgFgJgBgJQgBgKAFgHQAEgIAJgFQAIgGAJgBQAJgBAIAEQAIADAHAJQAEAHAAAHQABAGgCAFQgDAGgEAEIgJAIIgDACIgDABIgYgmQgFADgDAFQgBAEABAFIAEAJIAGAJIAHAGIgJAJIgIgIgAglh1IgHACIAQAaIAFgFQADgDABgEQAAgFgCgEQgEgFgDgBIgGgBIgDAAgAhyiDIA8g1IgRgUIALgJIAuA1IgLAKIgSgVIg7A1g");
	this.shape_1.setTransform(75.3,78.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).wait(2));

	// fill
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#406AB2","#1E3351"],[0.004,1],36.7,24.4,-33.9,-65.7).s().p("ACjNOIirjYQBNiJAGipIABgaIAAgJQgCiohJiHIgQghQgshHg/g/Qg2g2g7gmIgfgUQiJhPipgGIBnkHIhljsQEwAID3CQIAcASQB0BIBmBmQBvBuBLB9IASAgQCMD6ACEwIAAAKIAAAaQgGExiQD5g");
	this.shape_2.setTransform(57.3,87.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#E4950E","#673F07"],[0.004,1],36.7,24.4,-33.9,-65.7).s().p("ACjNOIirjYQBNiJAGipIABgaIAAgJQgCiohJiHIgQghQgshHg/g/Qg2g2g7gmIgfgUQiJhPipgGIBnkHIhljsQEwAID3CQIAcASQB0BIBmBmQBvBuBLB9IASAgQCMD6ACEwIAAAKIAAAaQgGExiQD5g");
	this.shape_3.setTransform(57.3,87.8);

	this.instance = new lib.Bitmap2();
	this.instance.setTransform(-5.2,-3.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,175.7);


(lib.mc_btn_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"up":0,"over":1,"down":2,"disabled":3});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}
	this.frame_1 = function() {
		/* stop();*/
	}
	this.frame_2 = function() {
		/* stop();*/
	}
	this.frame_3 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer 5
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiUCyIAGgVIBigDIgFASIgcABIgIAcIAXAPIgFARgAh9CxIAIAFIAUANIAHgXIgYAAIgJAAIgJAAIgBAAIAIAFgAhaB+IgKgEIgJgCIAFgPIAKADIAAAAIgEgGIgCgJQAAgEACgGQACgFAEgFQAFgEAHgBQAIgBAKADIAmANIgGARIgkgNQgHgCgGABQgFABgDAGQgBAGABAEIAFAHIADABIACABIAmANIgGARgAgcBBQgGAAgFgDQgKgGgBgMQAAgNAJgQIgBgBIgFgBQgDgBgDACQgDABgDAFQgDAFAAAEIgCAKIgLgDIABgLQACgGAEgHQAFgKAHgCQAGgCAHAAQAHACAHABIAVAMIAIAFIAFACIgGAOIgHgDIAAABQACAFgBAFQAAAFgDAGQgEAGgEADQgFADgEAAIgBAAgAgkAeIgBAKQABAEAEADQAFACADgBQAEgCACgDQACgFgBgEQAAgFgDgDIgBgBIgCgBIgIgFIgFALgAhIgtIAIgPIBUAyIgIANgAAqgMIABgFIABgGIgBgHIgCgHIgBgCIgBgBIgBAAIgCgBIg/gRIALgPIAjALIAGADIAHACIAAAAIgEgFIgFgGIgWgeIALgPIAaAqIAMATQAFAIACAGQACAGAAAGQABAHgCAEQgBAFgCADgAA4hfQAEgBAEgDIAHgGQAEgFAAgDQAAgDgDgDQgCgCgEABIgIADQgKAGgGAAQgHAAgEgEQgFgEgCgFQgBgGABgGQACgHAFgGIAHgGQAEgEADgBIAIALIgGADIgHAFQgDAEAAADQAAADADACQACACAEgBQADAAAGgEQAIgFAHAAQAGAAAGAFQAFAEABAGQACAFgCAGQgCAHgGAHIgIAHIgIAFgAA2iwIAMgMIAyAuIgMAMgAB0ioQAEgBAEgDIAHgGQAEgEAAgEQAAgDgDgCQgCgCgEAAIgIAEQgKAFgGAAQgHAAgEgDQgFgFgCgFQgBgGABgGQACgGAFgGIAHgHQAEgDADgBIAIAKIgGADIgHAGQgDADAAAEQAAACADACQACADAEgBQADgBAGgEQAIgEAHAAQAGAAAGAEQAFAEABAGQACAFgCAHQgCAGgGAHIgIAIIgIAFgAAni8QgDgCAAgEQAAgEADgDQADgDAEgBQADABADACQADADABADQgBAEgDAEQgDADgDAAIgBAAQgDAAgDgDg");
	this.shape.setTransform(41.3,77.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AiUCyIAGgVIBigDIgFASIgcABIgIAcIAXAPIgFARgAh9CxIAIAFIAUANIAHgXIgYAAIgJAAIgJAAIgBAAIAIAFgAhaB+IgKgEIgJgCIAFgPIAKADIAAAAIgEgGIgCgJQAAgEACgGQACgFAEgFQAFgEAHgBQAIgBAKADIAmANIgGARIgkgNQgHgCgGABQgFABgDAGQgBAGABAEIAFAHIADABIACABIAmANIgGARgAgcBBQgGAAgFgDQgKgGgBgMQAAgNAJgQIgBgBIgFgBQgDgBgDACQgDABgDAFQgDAFAAAEIgCAKIgLgDIABgLQACgGAEgHQAFgKAHgCQAGgCAHAAQAHACAHABIAVAMIAIAFIAFACIgGAOIgHgDIAAABQACAFgBAFQAAAFgDAGQgEAGgEADQgFADgEAAIgBAAgAgkAeIgBAKQABAEAEADQAFACADgBQAEgCACgDQACgFgBgEQAAgFgDgDIgBgBIgCgBIgIgFIgFALgAhIgtIAIgPIBUAyIgIANgAAqgMIABgFIABgGIgBgHIgCgHIgBgCIgBgBIgBAAIgCgBIg/gRIALgPIAjALIAGADIAHACIAAAAIgEgFIgFgGIgWgeIALgPIAaAqIAMATQAFAIACAGQACAGAAAGQABAHgCAEQgBAFgCADgAA4hfQAEgBAEgDIAHgGQAEgFAAgDQAAgDgDgDQgCgCgEABIgIADQgKAGgGAAQgHAAgEgEQgFgEgCgFQgBgGABgGQACgHAFgGIAHgGQAEgEADgBIAIALIgGADIgHAFQgDAEAAADQAAADADACQACACAEgBQADAAAGgEQAIgFAHAAQAGAAAGAFQAFAEABAGQACAFgCAGQgCAHgGAHIgIAHIgIAFgAA2iwIAMgMIAyAuIgMAMgAB0ioQAEgBAEgDIAHgGQAEgEAAgEQAAgDgDgCQgCgCgEAAIgIAEQgKAFgGAAQgHAAgEgDQgFgFgCgFQgBgGABgGQACgGAFgGIAHgHQAEgDADgBIAIAKIgGADIgHAGQgDADAAAEQAAACADACQACADAEgBQADgBAGgEQAIgEAHAAQAGAAAGAEQAFAEABAGQACAFgCAHQgCAGgGAHIgIAIIgIAFgAAni8QgDgCAAgEQAAgEADgDQADgDAEgBQADABADACQADADABADQgBAEgDAEQgDADgDAAIgBAAQgDAAgDgDg");
	this.shape_1.setTransform(41.3,77.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).wait(2));

	// fill
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#406AB2","#1E3351"],[0.004,1],-80.9,-40.1,-80.9,71).s().p("AnuNjIgmhLQguhiggiEQgYh4gBiCIAAgJIABgbQAGkwCQj6IAUggQBIhzBmhnQBvhuB9hLIAfgRQD5iME0gCIBmDtIhlEFQioACiKBIIgfARQhJAshAA/QgzA0gkA4IgUAgQhSCKgHCqIgBAfIAAAEQAABcAWBUIARA1QAPApAVAoIjzAqIi7DVIgDgFg");
	this.shape_2.setTransform(63.7,87.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#E4950E","#673F07"],[0.004,1],-80.9,-40.1,-80.9,71).s().p("AnuNjIgmhLQguhiggiEQgYh4gBiCIAAgJIABgbQAGkwCQj6IAUggQBIhzBmhnQBvhuB9hLIAfgRQD5iME0gCIBmDtIhlEFQioACiKBIIgfARQhJAshAA/QgzA0gkA4IgUAgQhSCKgHCqIgBAfIAAAEQAABcAWBUIARA1QAPApAVAoIjzAqIi7DVIgDgFg");
	this.shape_3.setTransform(63.7,87.3);

	this.instance = new lib.Bitmap1();
	this.instance.setTransform(-3.5,-3.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,127.3,174.6);


(lib.mc_btn_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"up":0,"over":1,"down":2,"disabled":3});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}
	this.frame_1 = function() {
		/* stop();*/
	}
	this.frame_2 = function() {
		/* stop();*/
	}
	this.frame_3 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer 8
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAVBUQgFgDgCgEQgDgFAAgFQAAgNALgGQALgHASAAIAAgBIgBgFQAAgDgDgCQgEgCgFAAIgKACIgJADIgDgLQADgCAHgCQAGgCAIAAQALAAAHAEQAFAEADAHQADAGgBAIIAAAYIABAJIAAAIIgPAAIgBgIIgBAAQgDAEgFADQgFACgHAAQgGAAgFgDgAAoA1QgFABgEADQgDADAAAFQAAAFADADQADACAEAAQAFAAAEgDQADgDABgDIAAgCIABgCIAAgKIgMABgABmBVQgEgCgDgCQgCgDgBgFQgCgEgBgHIAAggIgKAAIAAgNIAKAAIgBgMIARgFIABARIAQgBIAAANIgQAAIAAAfQAAAGADADQACADAFAAIAEAAIACgBIABANIgFACIgHAAQgFAAgEgBgACKAPIASgBIAFBEIgSABgAgTBRIAAgLIAAAAIgFAFQgDACgEACQgFABgGgBQgGAAgGgEQgEgDgCgHQgEgHACgLIAFgoIARACIgFAlQgBAIACAGQADAFAGABQAGABADgDQAFgCAAgDIACgDIAAgDIAGgoIAPACIgFAvIAAALIgBAJgADABOQgIgEgGgHQgFgIAAgLQgBgLAEgJQAEgIAHgFQAIgFAKAAQALgBAHAEQAJAEAEAHQAFAIAAAKQABANgEAIQgFAJgHAEQgIAEgJABIgCAAQgJAAgGgDgADNAWQgFABgEADQgDAEgBAFQgCAGABAFQAAAHACAFQADAFAEADQAEACAFAAQAFAAADgDQAEgEABgFQACgFgBgHQAAgFgCgGQgBgFgFgDQgDgDgFAAIgCAAgAhiBIIAJhhIASACIgKBhgAD9ASIgDgKIgBgIIAPgCIACAJQACgEACgDQACgBAFgCIAJgEQAGgBAGADQAGACAFADQAEAGABALIAGAoIgRACIgFgmQgBgHgEgEQgEgFgHABQgFABgDADQgCAEgBAEIAAADIAAADIAGAnIgSADgAiHA+IABgIIgBAAQgEADgFABQgGABgGgBQgHgCgDgEQgFgEgCgFQAAgFABgFQADgNAMgDQAMgEASAFIABgBIAAgFQAAgDgDgDQgBgDgHgBQgFgBgFAAQgFAAgEABIAAgJQAFgCAGAAQAGAAAJACQAKADAFAEQAFAFAAAHQABAGgCAIIgGAXIgCAJIgBAIgAiWAdQgDABgCAFQgBAFACADQACADAEABQAFABAEgBQAEgCADgEIAAgBIABgCIACgJIgLgCIgCAAQgEAAgEACgAjgAmIgFhGIASAFIABAiIAAAJIAAAJIAAAAIAEgIIAFgHIAUgcIARAFIgsA4gAk/gBIAnhVIAyAXIgGANIgigQIgLAWIAhAPIgGANIghgPIgLAZIAkAPIgGANgACLACQgCgCgBgCQAAgEACgDQADgCAEgBQAEAAADACQACADABAEQAAADgCABQgCADgFABQgEAAgDgDg");
	this.shape.setTransform(94,48.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAVBUQgFgDgCgEQgDgFAAgFQAAgNALgGQALgHASAAIAAgBIgBgFQAAgDgDgCQgEgCgFAAIgKACIgJADIgDgLQADgCAHgCQAGgCAIAAQALAAAHAEQAFAEADAHQADAGgBAIIAAAYIABAJIAAAIIgPAAIgBgIIgBAAQgDAEgFADQgFACgHAAQgGAAgFgDgAAoA1QgFABgEADQgDADAAAFQAAAFADADQADACAEAAQAFAAAEgDQADgDABgDIAAgCIABgCIAAgKIgMABgABmBVQgEgCgDgCQgCgDgBgFQgCgEgBgHIAAggIgKAAIAAgNIAKAAIgBgMIARgFIABARIAQgBIAAANIgQAAIAAAfQAAAGADADQACADAFAAIAEAAIACgBIABANIgFACIgHAAQgFAAgEgBgACKAPIASgBIAFBEIgSABgAgTBRIAAgLIAAAAIgFAFQgDACgEACQgFABgGgBQgGAAgGgEQgEgDgCgHQgEgHACgLIAFgoIARACIgFAlQgBAIACAGQADAFAGABQAGABADgDQAFgCAAgDIACgDIAAgDIAGgoIAPACIgFAvIAAALIgBAJgADABOQgIgEgGgHQgFgIAAgLQgBgLAEgJQAEgIAHgFQAIgFAKAAQALgBAHAEQAJAEAEAHQAFAIAAAKQABANgEAIQgFAJgHAEQgIAEgJABIgCAAQgJAAgGgDgADNAWQgFABgEADQgDAEgBAFQgCAGABAFQAAAHACAFQADAFAEADQAEACAFAAQAFAAADgDQAEgEABgFQACgFgBgHQAAgFgCgGQgBgFgFgDQgDgDgFAAIgCAAgAhiBIIAJhhIASACIgKBhgAD9ASIgDgKIgBgIIAPgCIACAJQACgEACgDQACgBAFgCIAJgEQAGgBAGADQAGACAFADQAEAGABALIAGAoIgRACIgFgmQgBgHgEgEQgEgFgHABQgFABgDADQgCAEgBAEIAAADIAAADIAGAnIgSADgAiHA+IABgIIgBAAQgEADgFABQgGABgGgBQgHgCgDgEQgFgEgCgFQAAgFABgFQADgNAMgDQAMgEASAFIABgBIAAgFQAAgDgDgDQgBgDgHgBQgFgBgFAAQgFAAgEABIAAgJQAFgCAGAAQAGAAAJACQAKADAFAEQAFAFAAAHQABAGgCAIIgGAXIgCAJIgBAIgAiWAdQgDABgCAFQgBAFACADQACADAEABQAFABAEgBQAEgCADgEIAAgBIABgCIACgJIgLgCIgCAAQgEAAgEACgAjgAmIgFhGIASAFIABAiIAAAJIAAAJIAAAAIAEgIIAFgHIAUgcIARAFIgsA4gAk/gBIAnhVIAyAXIgGANIgigQIgLAWIAhAPIgGANIghgPIgLAZIAkAPIgGANgACLACQgCgCgBgCQAAgEACgDQADgCAEgBQAEAAADACQACADABAEQAAADgCABQgCADgFABQgEAAgDgDg");
	this.shape_1.setTransform(94,48.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).wait(2));

	// fill
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#406AB2","#1E3351"],[0.004,1],-18.6,12.8,84,-28.7).s().p("AADGfIgWAAQkygFj4iPIgggTQh2hJhphpQhthrhKh7IC7jUID0gqQAqBGBABAQA1A1A9AoIAfATQCKBQCoAGIAbABIAHAAQCpgCCMhKIAegSQBHgrA+g+QA4g4Aog9ICtDYIAIACID8AeQhKB1hoBmQhsBth6BKIggASQj5CNk0ADIgMAAg");
	this.shape_2.setTransform(101.2,41.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#E4950E","#673F07"],[0.004,1],-18.6,12.8,84,-28.7).s().p("AADGfIgWAAQkygFj4iPIgggTQh2hJhphpQhthrhKh7IC7jUID0gqQAqBGBABAQA1A1A9AoIAfATQCKBQCoAGIAbABIAHAAQCpgCCMhKIAegSQBHgrA+g+QA4g4Aog9ICtDYIAIACID8AeQhKB1hoBmQhsBth6BKIggASQj5CNk0ADIgMAAg");
	this.shape_3.setTransform(101.2,41.6);

	this.instance = new lib.Bitmap5();
	this.instance.setTransform(-4.7,-4.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,202.4,83.2);


(lib.mc_btn_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"up":0,"over":1,"down":2,"disabled":3});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}
	this.frame_1 = function() {
		/* stop();*/
	}
	this.frame_2 = function() {
		/* stop();*/
	}
	this.frame_3 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer 8
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAbDTQgHgEgDgGQgEgGgDgGIgCgNQAAgHABgEIANgBIAAAJQAAAFACAGQACAGACADQAEAEAFABQAFABAHgCIAFgCIAAAAQgFgCgEgEQgEgEgCgGQgCgIABgIQADgIAFgFQAGgGAJgDQALgDAJABQAJACAHAFQAFAFADAIQADAIgCAFQgCAGgDAEIAJgDIAFAPIgIACIgLADIgkAMQgKADgJAAIgCAAQgHAAgFgDgABECeQgGABgEADQgEAEgCAEQgBAFABAFQACAEAEADQAEADAFAAIADAAIACgBIALgEIADgBIACgBQADgDADgEQACgEgCgGQgDgHgGgCIgIgBQgEAAgFACgAAaB+IAkgNQAHgCADgFQAEgEgCgHQgCgFgDgCQgFgCgEAAIgCAAIgEABIglAOIgGgRIAtgQIAKgEIAJgDIAFAOIgJAEIAAABIAHACIAGAFQADAEACAFQACAGAAAGQgCAGgEAFQgFAGgKAEIgmANgAgBA1IA8gcIAHAQIg+AcgAgIAkIgDgHQgDgEAAgEIABgIQABgDAEgEIAIgGIAcgMIgEgJIALgFIAFAJIAMgGIALANIgQAIIAHAMIgLAGIgHgPIgbAOQgGACgCADQgBAEABAEIADAEIABACIgJAGIgEgEgABNAjQgDgCgDgEQAAgEAAgDQACgEAEgBQAEgCADABQADACACAEQABAEgBADQgBADgEACIgEABIgDAAgAgdgNQgGgDgFgIIgEgLQgCgFAAgEIAMgEIABAJIAEAIQADAFADABQADABADgCQADgBAAgEQACgDgDgGQgCgKACgHQACgHAFgCQAFgEAEAAQAGAAAGAEQAFADAFAHIAEAJIABAIIgMAEIAAgGQgCgFgCgDQgCgEgDgBQgDgBgDACQgBABAAADIAAALQABAJgBAHQAAAGgHAEQgFADgGAAQgGAAgFgEgAg+hCIgJgKQgFgJgBgJQgBgKAFgHQAEgIAJgFQAIgGAJgBQAJgBAIAEQAIADAHAJQAEAHAAAHQABAGgCAFQgDAGgEAEIgJAIIgDACIgDABIgYgmQgFADgDAFQgBAEABAFIAEAJIAGAJIAHAGIgJAJIgIgIgAglh1IgHACIAQAaIAFgFQADgDABgEQAAgFgCgEQgEgFgDgBIgGgBIgDAAgAhyiDIA8g1IgRgUIALgJIAuA1IgLAKIgSgVIg7A1g");
	this.shape.setTransform(75.3,78.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAbDTQgHgEgDgGQgEgGgDgGIgCgNQAAgHABgEIANgBIAAAJQAAAFACAGQACAGACADQAEAEAFABQAFABAHgCIAFgCIAAAAQgFgCgEgEQgEgEgCgGQgCgIABgIQADgIAFgFQAGgGAJgDQALgDAJABQAJACAHAFQAFAFADAIQADAIgCAFQgCAGgDAEIAJgDIAFAPIgIACIgLADIgkAMQgKADgJAAIgCAAQgHAAgFgDgABECeQgGABgEADQgEAEgCAEQgBAFABAFQACAEAEADQAEADAFAAIADAAIACgBIALgEIADgBIACgBQADgDADgEQACgEgCgGQgDgHgGgCIgIgBQgEAAgFACgAAaB+IAkgNQAHgCADgFQAEgEgCgHQgCgFgDgCQgFgCgEAAIgCAAIgEABIglAOIgGgRIAtgQIAKgEIAJgDIAFAOIgJAEIAAABIAHACIAGAFQADAEACAFQACAGAAAGQgCAGgEAFQgFAGgKAEIgmANgAgBA1IA8gcIAHAQIg+AcgAgIAkIgDgHQgDgEAAgEIABgIQABgDAEgEIAIgGIAcgMIgEgJIALgFIAFAJIAMgGIALANIgQAIIAHAMIgLAGIgHgPIgbAOQgGACgCADQgBAEABAEIADAEIABACIgJAGIgEgEgABNAjQgDgCgDgEQAAgEAAgDQACgEAEgBQAEgCADABQADACACAEQABAEgBADQgBADgEACIgEABIgDAAgAgdgNQgGgDgFgIIgEgLQgCgFAAgEIAMgEIABAJIAEAIQADAFADABQADABADgCQADgBAAgEQACgDgDgGQgCgKACgHQACgHAFgCQAFgEAEAAQAGAAAGAEQAFADAFAHIAEAJIABAIIgMAEIAAgGQgCgFgCgDQgCgEgDgBQgDgBgDACQgBABAAADIAAALQABAJgBAHQAAAGgHAEQgFADgGAAQgGAAgFgEgAg+hCIgJgKQgFgJgBgJQgBgKAFgHQAEgIAJgFQAIgGAJgBQAJgBAIAEQAIADAHAJQAEAHAAAHQABAGgCAFQgDAGgEAEIgJAIIgDACIgDABIgYgmQgFADgDAFQgBAEABAFIAEAJIAGAJIAHAGIgJAJIgIgIgAglh1IgHACIAQAaIAFgFQADgDABgEQAAgFgCgEQgEgFgDgBIgGgBIgDAAgAhyiDIA8g1IgRgUIALgJIAuA1IgLAKIgSgVIg7A1g");
	this.shape_1.setTransform(75.3,78.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).wait(2));

	// fill
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#406AB2","#1E3351"],[0.004,1],36.7,24.4,-33.9,-65.7).s().p("ACjNOIirjYQBNiJAGipIABgaIAAgJQgCiohJiHIgQghQgshHg/g/Qg2g2g7gmIgfgUQiJhPipgGIBnkHIhljsQEwAID3CQIAcASQB0BIBmBmQBvBuBLB9IASAgQCMD6ACEwIAAAKIAAAaQgGExiQD5g");
	this.shape_2.setTransform(57.3,87.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#E4950E","#673F07"],[0.004,1],36.7,24.4,-33.9,-65.7).s().p("ACjNOIirjYQBNiJAGipIABgaIAAgJQgCiohJiHIgQghQgshHg/g/Qg2g2g7gmIgfgUQiJhPipgGIBnkHIhljsQEwAID3CQIAcASQB0BIBmBmQBvBuBLB9IASAgQCMD6ACEwIAAAKIAAAaQgGExiQD5g");
	this.shape_3.setTransform(57.3,87.8);

	this.instance = new lib.Bitmap4();
	this.instance.setTransform(-5.2,-3.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,114.7,175.7);


(lib.mc_btn_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{"up":0,"over":1,"down":2,"disabled":3});

	// timeline functions:
	this.frame_0 = function() {
		/* stop();*/
	}
	this.frame_1 = function() {
		/* stop();*/
	}
	this.frame_2 = function() {
		/* stop();*/
	}
	this.frame_3 = function() {
		/* stop();*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1));

	// Layer 9
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AiUCyIAGgVIBigDIgFASIgcABIgIAcIAXAPIgFARgAh9CxIAIAFIAUANIAHgXIgYAAIgJAAIgJAAIgBAAIAIAFgAhaB+IgKgEIgJgCIAFgPIAKADIAAAAIgEgGIgCgJQAAgEACgGQACgFAEgFQAFgEAHgBQAIgBAKADIAmANIgGARIgkgNQgHgCgGABQgFABgDAGQgBAGABAEIAFAHIADABIACABIAmANIgGARgAgcBBQgGAAgFgDQgKgGgBgMQAAgNAJgQIgBgBIgFgBQgDgBgDACQgDABgDAFQgDAFAAAEIgCAKIgLgDIABgLQACgGAEgHQAFgKAHgCQAGgCAHAAQAHACAHABIAVAMIAIAFIAFACIgGAOIgHgDIAAABQACAFgBAFQAAAFgDAGQgEAGgEADQgFADgEAAIgBAAgAgkAeIgBAKQABAEAEADQAFACADgBQAEgCACgDQACgFgBgEQAAgFgDgDIgBgBIgCgBIgIgFIgFALgAhIgtIAIgPIBUAyIgIANgAAqgMIABgFIABgGIgBgHIgCgHIgBgCIgBgBIgBAAIgCgBIg/gRIALgPIAjALIAGADIAHACIAAAAIgEgFIgFgGIgWgeIALgPIAaAqIAMATQAFAIACAGQACAGAAAGQABAHgCAEQgBAFgCADgAA4hfQAEgBAEgDIAHgGQAEgFAAgDQAAgDgDgDQgCgCgEABIgIADQgKAGgGAAQgHAAgEgEQgFgEgCgFQgBgGABgGQACgHAFgGIAHgGQAEgEADgBIAIALIgGADIgHAFQgDAEAAADQAAADADACQACACAEgBQADAAAGgEQAIgFAHAAQAGAAAGAFQAFAEABAGQACAFgCAGQgCAHgGAHIgIAHIgIAFgAA2iwIAMgMIAyAuIgMAMgAB0ioQAEgBAEgDIAHgGQAEgEAAgEQAAgDgDgCQgCgCgEAAIgIAEQgKAFgGAAQgHAAgEgDQgFgFgCgFQgBgGABgGQACgGAFgGIAHgHQAEgDADgBIAIAKIgGADIgHAGQgDADAAAEQAAACADACQACADAEgBQADgBAGgEQAIgEAHAAQAGAAAGAEQAFAEABAGQACAFgCAHQgCAGgGAHIgIAIIgIAFgAAni8QgDgCAAgEQAAgEADgDQADgDAEgBQADABADACQADADABADQgBAEgDAEQgDADgDAAIgBAAQgDAAgDgDg");
	this.shape.setTransform(41.3,77.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AiUCyIAGgVIBigDIgFASIgcABIgIAcIAXAPIgFARgAh9CxIAIAFIAUANIAHgXIgYAAIgJAAIgJAAIgBAAIAIAFgAhaB+IgKgEIgJgCIAFgPIAKADIAAAAIgEgGIgCgJQAAgEACgGQACgFAEgFQAFgEAHgBQAIgBAKADIAmANIgGARIgkgNQgHgCgGABQgFABgDAGQgBAGABAEIAFAHIADABIACABIAmANIgGARgAgcBBQgGAAgFgDQgKgGgBgMQAAgNAJgQIgBgBIgFgBQgDgBgDACQgDABgDAFQgDAFAAAEIgCAKIgLgDIABgLQACgGAEgHQAFgKAHgCQAGgCAHAAQAHACAHABIAVAMIAIAFIAFACIgGAOIgHgDIAAABQACAFgBAFQAAAFgDAGQgEAGgEADQgFADgEAAIgBAAgAgkAeIgBAKQABAEAEADQAFACADgBQAEgCACgDQACgFgBgEQAAgFgDgDIgBgBIgCgBIgIgFIgFALgAhIgtIAIgPIBUAyIgIANgAAqgMIABgFIABgGIgBgHIgCgHIgBgCIgBgBIgBAAIgCgBIg/gRIALgPIAjALIAGADIAHACIAAAAIgEgFIgFgGIgWgeIALgPIAaAqIAMATQAFAIACAGQACAGAAAGQABAHgCAEQgBAFgCADgAA4hfQAEgBAEgDIAHgGQAEgFAAgDQAAgDgDgDQgCgCgEABIgIADQgKAGgGAAQgHAAgEgEQgFgEgCgFQgBgGABgGQACgHAFgGIAHgGQAEgEADgBIAIALIgGADIgHAFQgDAEAAADQAAADADACQACACAEgBQADAAAGgEQAIgFAHAAQAGAAAGAFQAFAEABAGQACAFgCAGQgCAHgGAHIgIAHIgIAFgAA2iwIAMgMIAyAuIgMAMgAB0ioQAEgBAEgDIAHgGQAEgEAAgEQAAgDgDgCQgCgCgEAAIgIAEQgKAFgGAAQgHAAgEgDQgFgFgCgFQgBgGABgGQACgGAFgGIAHgHQAEgDADgBIAIAKIgGADIgHAGQgDADAAAEQAAACADACQACADAEgBQADgBAGgEQAIgEAHAAQAGAAAGAEQAFAEABAGQACAFgCAHQgCAGgGAHIgIAIIgIAFgAAni8QgDgCAAgEQAAgEADgDQADgDAEgBQADABADACQADADABADQgBAEgDAEQgDADgDAAIgBAAQgDAAgDgDg");
	this.shape_1.setTransform(41.3,77.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},2).wait(2));

	// fill
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#406AB2","#1E3351"],[0.004,1],-80.9,-40.1,-80.9,71).s().p("AnuNjIgmhLQguhiggiEQgYh4gBiCIAAgJIABgbQAGkwCQj6IAUggQBIhzBmhnQBvhuB9hLIAfgRQD5iME0gCIBmDtIhlEFQioACiKBIIgfARQhJAshAA/QgzA0gkA4IgUAgQhSCKgHCqIgBAfIAAAEQAABcAWBUIARA1QAPApAVAoIjzAqIi7DVIgDgFg");
	this.shape_2.setTransform(63.7,87.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#E4950E","#673F07"],[0.004,1],-80.9,-40.1,-80.9,71).s().p("AnuNjIgmhLQguhiggiEQgYh4gBiCIAAgJIABgbQAGkwCQj6IAUggQBIhzBmhnQBvhuB9hLIAfgRQD5iME0gCIBmDtIhlEFQioACiKBIIgfARQhJAshAA/QgzA0gkA4IgUAgQhSCKgHCqIgBAfIAAAEQAABcAWBUIARA1QAPApAVAoIjzAqIi7DVIgDgFg");
	this.shape_3.setTransform(63.7,87.3);

	this.instance = new lib.Bitmap6();
	this.instance.setTransform(-3.5,-3.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2}]}).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,127.3,174.6);


// stage content:
(lib.p_10 = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{step_01:8,step_02:15,step_03:22,step_04:29,step_05:36,step_06:43});

	// timeline functions:
	this.frame_4 = function() {
		this.dispatchEvent(new createjs.Event("anim_stop",false,true));this.stop();
		this.btn_1.addEventListener("click", function()
			{
				var evt = new createjs.Event("btn_click",false,true); 
				evt["targetName"] 	=	"btn_1";
		 	this.dispatchEvent(evt); 
				this.gotoAndStop("step_01");
			}.bind(this));
		this.btn_2.addEventListener("click", function()
			{
				var evt = new createjs.Event("btn_click",false,true); 
				evt["targetName"] 	=	"btn_2";
		 	this.dispatchEvent(evt); 
				this.gotoAndStop("step_02");
			}.bind(this));
		this.btn_3.addEventListener("click", function()
			{
				var evt = new createjs.Event("btn_click",false,true); 
				evt["targetName"] 	=	"btn_3";
		 	this.dispatchEvent(evt); 
				this.gotoAndStop("step_03");
			}.bind(this));
		this.btn_4.addEventListener("click", function()
			{
				var evt = new createjs.Event("btn_click",false,true); 
				evt["targetName"] 	=	"btn_4";
		 	this.dispatchEvent(evt); 
				this.gotoAndStop("step_04");
			}.bind(this));
		this.btn_5.addEventListener("click", function()
			{
				var evt = new createjs.Event("btn_click",false,true); 
				evt["targetName"] 	=	"btn_5";
		 	this.dispatchEvent(evt); 
				this.gotoAndStop("step_05");
			}.bind(this));
		this.btn_6.addEventListener("click", function()
			{
				var evt = new createjs.Event("btn_click",false,true); 
				evt["targetName"] 	=	"btn_6";
		 	this.dispatchEvent(evt); 
				this.gotoAndStop("step_06");
			}.bind(this));
	}
	this.frame_8 = function() {
		this.dispatchEvent(new createjs.Event("anim_stop",false,true));this.stop();
	}
	this.frame_15 = function() {
		this.dispatchEvent(new createjs.Event("anim_stop",false,true));this.stop();
	}
	this.frame_22 = function() {
		this.dispatchEvent(new createjs.Event("anim_stop",false,true));this.stop();
	}
	this.frame_29 = function() {
		this.dispatchEvent(new createjs.Event("anim_stop",false,true));this.stop();
	}
	this.frame_36 = function() {
		this.dispatchEvent(new createjs.Event("anim_stop",false,true));this.stop();
	}
	this.frame_43 = function() {
		this.dispatchEvent(new createjs.Event("anim_stop",false,true));this.stop();
	}
	this.frame_49 = function() {
		this.dispatchEvent(new createjs.Event("anim_stop",false,true));this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(4).call(this.frame_4).wait(4).call(this.frame_8).wait(7).call(this.frame_15).wait(7).call(this.frame_22).wait(7).call(this.frame_29).wait(7).call(this.frame_36).wait(7).call(this.frame_43).wait(6).call(this.frame_49).wait(1));

	// Layer 6
	this.instance = new lib.mc_btn_1("single",2);
	this.instance.setTransform(154.4,112.6,1,1,0,0,0,63.6,87.3);

	this.instance_1 = new lib.mc_btn_2("single",2);
	this.instance_1.setTransform(268.8,113.1,1,1,0,0,0,57.3,87.8);

	this.instance_2 = new lib.mc_btn_3("single",2);
	this.instance_2.setTransform(208.2,219.1,1,1,0,0,0,101.2,41.6);

	this.instance_3 = new lib.mc_btn_4("single",2);
	this.instance_3.setTransform(608,112.6,1,1,0,0,0,63.6,87.3);

	this.instance_4 = new lib.mc_btn_5("single",2);
	this.instance_4.setTransform(722.4,113.1,1,1,0,0,0,57.3,87.8);

	this.instance_5 = new lib.mc_btn_6("single",2);
	this.instance_5.setTransform(661.8,219.1,1,1,0,0,0,101.2,41.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance}]},8).to({state:[]},1).to({state:[{t:this.instance_1}]},6).to({state:[]},1).to({state:[{t:this.instance_2}]},6).to({state:[]},1).to({state:[{t:this.instance_3}]},6).to({state:[]},1).to({state:[{t:this.instance_4}]},6).to({state:[]},1).to({state:[{t:this.instance_5}]},6).to({state:[]},1).wait(6));

	// btn
	this.btn_1 = new lib.mc_btn_1();
	this.btn_1.setTransform(154.4,112.6,1,1,0,0,0,63.6,87.3);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.mc_btn_1(), 3);

	this.btn_6 = new lib.mc_btn_6();
	this.btn_6.setTransform(661.8,219.1,1,1,0,0,0,101.2,41.6);
	new cjs.ButtonHelper(this.btn_6, 0, 1, 2, false, new lib.mc_btn_6(), 3);

	this.btn_5 = new lib.mc_btn_5();
	this.btn_5.setTransform(722.4,113.1,1,1,0,0,0,57.3,87.8);
	new cjs.ButtonHelper(this.btn_5, 0, 1, 2, false, new lib.mc_btn_5(), 3);

	this.btn_4 = new lib.mc_btn_4();
	this.btn_4.setTransform(608,112.6,1,1,0,0,0,63.6,87.3);
	new cjs.ButtonHelper(this.btn_4, 0, 1, 2, false, new lib.mc_btn_4(), 3);

	this.btn_3 = new lib.mc_btn_3();
	this.btn_3.setTransform(208.2,219.1,1,1,0,0,0,101.2,41.6);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.mc_btn_3(), 3);

	this.btn_2 = new lib.mc_btn_2();
	this.btn_2.setTransform(268.8,113.1,1,1,0,0,0,57.3,87.8);
	new cjs.ButtonHelper(this.btn_2, 0, 1, 2, false, new lib.mc_btn_2(), 3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.btn_2},{t:this.btn_3},{t:this.btn_4},{t:this.btn_5},{t:this.btn_6},{t:this.btn_1}]},4).wait(46));

	// circul
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B7C3D4").s().p("AqcKcQkVkVABmHQgBmGEVkVQEVkVGHAAQGHAAEVEVQEWEVAAGGQAAGHkWEVQkVEVmHAAQmHAAkVkVgAnEnEQi8C8AAEIQAAEJC8C8QC8C8EIAAQEJAAC8i8QC8i8AAkJQAAkIi8i8Qi8i7kJAAQkIAAi8C7g");
	this.shape.setTransform(662.1,142.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#DCEAFF").s().p("AtYNYQljliAAn2QAAn1FjljQFkljH0AAQH1AAFjFjQFkFjAAH1QAAH2lkFiQljFkn1AAQn0AAlklkgAqbqcQkVEVAAGHQAAGHEVEVQEVEVGGAAQGIAAEUkVQEWkVAAmHQAAmHkWkVQkUkVmIAAQmGAAkVEVg");
	this.shape_1.setTransform(662.1,143);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#DCEAFF").s().p("AtYNYQljliAAn2QAAn1FjljQFkljH0AAQH1AAFjFjQFkFjAAH1QAAH2lkFiQljFkn1AAQn0AAlklkgAqbqcQkVEVAAGHQAAGHEVEVQEVEVGGAAQGIAAEUkVQEWkVAAmHQAAmHkWkVQkUkVmIAAQmGAAkVEVg");
	this.shape_2.setTransform(208.5,143);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B7C3D4").s().p("AqcKcQkVkVABmHQgBmGEVkVQEVkVGHAAQGHAAEVEVQEWEVAAGGQAAGHkWEVQkVEVmHAAQmHAAkVkVgAnEnEQi8C8AAEIQAAEJC8C8QC8C8EIAAQEJAAC8i8QC8i8AAkJQAAkIi8i8Qi8i7kJAAQkIAAi8C7g");
	this.shape_3.setTransform(208.5,142.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]},4).wait(46));

	// bg_
	this.instance_6 = new lib.gr_bg1("synched",0);
	this.instance_6.setTransform(662.3,166.4,1,1,0,0,0,215,162);

	this.instance_7 = new lib.gr_bg1("synched",0);
	this.instance_7.setTransform(208.7,166.4,1,1,0,0,0,215,162);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(1,1,1).p("AfcAAMg+3AAA");
	this.shape_4.setTransform(208.6,2.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4},{t:this.instance_7},{t:this.instance_6}]},3).wait(47));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = null;

return lib;
	};