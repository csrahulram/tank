define([
	'mediaplayer', 
	'framework/component/AbstractComponent', 
	'framework/core/PopupManager', 
	'framework/utils/Logger'
], function(mediaplayer, AbstractComponent, PopupManager, Logger) {
    function MediaPlayer() {
        //Logger.logDebug('MediaPlayer.CONSTRUCTOR() ');
        AbstractComponent.call(this);
        this.popupEventHandler = this.popupEventHandler.bind(this);
        this.oMedia;
        return this;
    }


    MediaPlayer.prototype = Object.create(AbstractComponent.prototype);
    MediaPlayer.prototype.constructor = MediaPlayer;

    MediaPlayer.prototype.init = function(p_sID, p_oConfig, p_$xmlComponent) {
        AbstractComponent.prototype.init.call(this, p_sID, p_oConfig, p_$xmlComponent);
    };

    MediaPlayer.prototype.createComponent = function() {
        var oScope = this;
        this.oMedia = this.$component.find("video,audio");
        if(this.$xmlData.attr("class") == "videoplayer") {
            var transcript = this.$xmlData.find('transcript').text();
            var sStyle = this.$xmlData.find('transcript').attr('style');
            //oMedia.hide();
            this.oMedia.acornMediaPlayer({
                themes : 'access accesslight',
                captionsOn : true
            });
            this.oMedia.show();
            //Page load completed only after video player loaded
            this.$component.find(".access").addClass("accesslight");
            this.$component.find(".acorn-transcript-button").click(function() {
                oScope.openPopup("popup_close", "Transcript", transcript, oScope.$component, sStyle);
                //$(this).focusout();
                $("#btn_continue").focus();
                $("#btn_continue").blur();
            });
        }
        /*if(this.$xmlData.attr("class") == "audioplayer") {
            if(this.$xmlData.attr("playOnLoad") == "true")
                AudioManager.playAudio(this.$xmlData.attr("id"));
            $(".ui-play-pause-btn").on('click', function(e) {
                if($(this).is(":checked")) {
                    AudioManager.setVolume(100);
                } else
                    AudioManager.setVolume(0);
            });
            if(navigator.userAgent.match(/(iPod|iPhone|iPad)/)) {
                if(AudioManager.sIosPlay) {
                    $("#ios_play").removeClass("hide");
                    $("#ios_play button").on('click', function() {
                        AudioManager.stop(this.$xmlData.attr("id"));
                        AudioManager.playAudio(this.$xmlData.attr("id"));
                        AudioManager.sIosPlay = false;
                        $("#ios_play").addClass("hide");
                    });
                }
            }
        }*/
        this.dispatchComponentLoadedEvent();
        this.setCompleted();
        /* TODO: notify when video is compete */
    };
    MediaPlayer.prototype.play = function() {
    };
    MediaPlayer.prototype.pause = function() {
    };
    MediaPlayer.prototype.isPlaying = function() {
    };
    MediaPlayer.prototype.getComponentConfig = function() {
        return {
            /* TODO: add configs params */
        };
    };
    MediaPlayer.prototype.openPopup = function(p_sPopupID, p_sTitle, p_sContent, p_$returnFocusTo, p_sClassesToAdd, p_fCallback, p_aArgs) {
        //Logger.logDebug('MediaPlayer.openPopup() | '+p_sPopupID, p_sTitle,
        // p_sContent, p_$returnFocusTo, p_sClassesToAdd);
        oPopup = PopupManager.openPopup(p_sPopupID, {
            txt_title : p_sTitle,
            txt_content : p_sContent
        }, p_$returnFocusTo, p_sClassesToAdd);
        oPopup.addEventListener('POPUP_CLOSE', this.popupEventHandler);
        oPopup.addEventListener('POPUP_EVENT', this.popupEventHandler);
        if(p_fCallback) {
            oPopup.setCallback(this, p_fCallback, p_aArgs);
        }
        return oPopup;
    };
    MediaPlayer.prototype.closePopup = function(p_sPopupID) {
        //Logger.logDebug('MediaPlayer.closePopup() | '+p_sPopupID);

        return true;
    };

    MediaPlayer.prototype.popupEventHandler = function(e) {
        var sEventType = e.type, 
		oPopup = e.target, 
		sPopupID = oPopup.getID();
        //Logger.logDebug('MediaPlayer.popupEventHandler() | Event Type = '+sEventType+' : Popup ID = '+sPopupID+' : Event Src = '+e.eventSrc);

        if(sEventType === 'POPUP_EVENT' || sEventType === 'POPUP_CLOSE') {
            oPopup.removeEventListener('POPUP_CLOSE', this.popupEventHandler);
            oPopup.removeEventListener('POPUP_EVENT', this.popupEventHandler);
            if(sEventType === 'POPUP_EVENT') {
                PopupManager.closePopup(sPopupID);
            }
            $(window).focus();
        }
    };

    MediaPlayer.prototype.destroy = function() {
        this.popupEventHandler = null;
        this.prototype = null;

        AbstractComponent.prototype.destroy.call(this);
    };
    MediaPlayer.prototype.toString = function() {
        return 'framework/component/MediaPlayer';
    };

    return MediaPlayer;
});
