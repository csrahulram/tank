define(['jquery', 
        'framework/utils/globals', 
        'framework/core/PopupManager', 
        'framework/utils/EventDispatcher',
         'framework/utils/Logger', 
         'framework/core/ActivityMarkupCollection',
         'framework/core/AudioManager'
         ],
     function($, Globals, PopupManager, EventDispatcher, Logger, ActivityMarkupCollection, AudioManager) {

    /**
     * Sachin Tumbre and Sameet Naik (18/08/2015) - 
     */
    function ComponentAbstract() {
        EventDispatcher.call(this);
        this.sScoringUID;
        this.sGUID;
        this.bIsSimulation;
        this.$domView;
        this.ParameterizedScore;
        this.oDataModel;
        this.$btnSubmit;
        this.bLoaded;
        this.sQuestionID;
        this.oFeedbackHistory;
        this.$btnReset;
        this.$btnShowAns;
        this.$btnUserAns;
        this.bHasShowAns;
        this.bHasReset;
        this.attempted;
        this.onModelReady = this.onModelReady.bind(this);
        this.popupEventHandler = this.popupEventHandler.bind(this);

        return this;
    }


    ComponentAbstract.prototype = Object.create(EventDispatcher.prototype);
    ComponentAbstract.prototype.constructor = ComponentAbstract;

    ComponentAbstract.prototype.init = function(p_$xmlActivityNode, p_$domView, p_sGUID, p_sScoringUID, p_bIsSimulation) {
        //Logger.logDebug('ComponentAbstract.init() ' + p_sScoringUID + ' | ' + p_sGUID);
        this.sScoringUID = p_sScoringUID;
        this.sGUID = p_sGUID;
        this.bIsSimulation = p_bIsSimulation;
        this.$domView = this.fetchMarkup(p_$domView);
        this._createDataModel(p_$xmlActivityNode[0]);
        this.oDataModel.addEventListener('MODEL_READY', this.onModelReady);
        this.oDataModel.loadDependencies();
    };

    /**
     * Sachin Tumbre(12/03/2104) - Load dependent resource and notify Listeners
     */
    ComponentAbstract.prototype.onModelReady = function() {
        //Logger.logDebug('ComponentAbstract.onModelReady() '+this.sScoringUID+' | '+this.sGUID );
        //this.oDataModel.setScoringUID(p_sScoringUID || p_sGUID || '');
        this.oDataModel.setIsSimulation(this.bIsSimulation || false);
        this.oDataModel.checkFeedBackTypeAndInitializeScore();
        this.oDataModel.checkFeedBackTypeAndInitializeFeedback();

		this.mandatory = (this.oDataModel.oDataModel._mandatory) ?(this.oDataModel.oDataModel._mandatory.toLowerCase() === "true") : true; 
        this.setContent();
        this._populateLayout();
        // ** Calling the concreate class "init" method
        //Populate Parameters if parameter based feedback
    };

    ComponentAbstract.prototype.fetchMarkup = function(p_$domView) {
        //Logger.logDebug('ComponentAbstract.fetchMarkup() | '+p_$domView.children().length);
        if (p_$domView.children().length === 0) {
            var sMarkupID = p_$domView[0].getAttribute('data-markup');
            if (!sMarkupID || sMarkupID === '') {
                Logger.logError('ComponentAbstract.fetchMarkup() | ERROR: Page Activity DOM has no "data-markup" attribute declared');
            }
            var $activityMarkup = ActivityMarkupCollection.getMarkup(sMarkupID);
            $activityMarkup.attr({
                'id' : p_$domView.attr('id'),
                'class' : p_$domView.attr('class')
            });
            p_$domView.replaceWith($activityMarkup);
            return $activityMarkup;
        }
        return p_$domView;
    };

    ComponentAbstract.prototype.setContent = function() {
        var o = this.oDataModel.getPageTextCollection();
        if (o) {
            var oPageText = o.pageText, nPageTextLength = oPageText.length, i;
            if (nPageTextLength) {
                for (var i = 0; i < nPageTextLength; i++) {
                    var oPageTextPointer = oPageText[i];
                    this.populateContent(oPageTextPointer);
                };
            } else {
                this.populateContent(oPageText);
            }
        }
    };

    ComponentAbstract.prototype.populateContent = function(oPageTextPointer) {
        var sClassName = oPageTextPointer._class || '', sID = oPageTextPointer._id || '', sContent = oPageTextPointer.__cdata;
        //Logger.logDebug('ComponentAbstract.populateContent() | ');

        if (sID) {
            //Logger.logDebug('\tID = '+sID);
            Globals.getElementByID(this.$domView, sID, 'ComponentAbstract.populateContent() | ID = ' + sID).html(sContent);
            return true;
        }
        if (sClassName) {
            //Logger.logDebug('\tClassName = '+sClassName);
            Globals.getElementByClassName(this.$domView, sClassName, 'ComponentAbstract.populateContent() | Class Name = ' + sClassName).html(sContent);
        }
    };

    ComponentAbstract.prototype.updateDataModel = function(p_xml) {
        //Logger.logDebug('ComponentAbstract.updateDataModel() '+Globals.toXMLString(p_xml[0]));
        this.oDataModel.updateDataModel(p_xml[0]);
    };

    /**
     * Submit button listener
     * @param p_selectedOptionID - Selected option
     * Abstract method
     */
    ComponentAbstract.prototype._evaluate = function(p_selection) {
        if (this.oDataModel.displayTickCross()) {
            if (this.oDataModel.getTickCrossDisplayTrigger() !== undefined && this.oDataModel.getTickCrossDisplayTrigger().toUpperCase() === "SUBMIT" && this.isAttemptsCompleted()) {
                this.displayTickCross();
            }
        }
    };
    
    ComponentAbstract.prototype.displayTickCross = function() {
		var aOptions 	= this.getOptions(),
		tickcrossType	= this.oDataModel.oDataModel._tickcrosstype || null,
		sCorrect 		= this.oDataModel.oDataModel._correctAnswer,
		aCorrect		= sCorrect.split(',');
		
		for (var i=0; i < aOptions.length; i++) {
			var opt 		= aOptions[i];
			var isCorrect 	= (aCorrect.indexOf(opt.getID()) != -1);
			var selected 	= opt.isSelected();
		  	var excludeSel 	= (!isCorrect && !selected && (tickcrossType && tickcrossType.toLowerCase() === "compact"));
		  	if(excludeSel )continue;
		  		
		  	if(isCorrect){
		  		opt.getView().addClass('correct display-result');
		  	}else{
		  		opt.getView().addClass('incorrect display-result');
		  	}
		};
         this.$domView.find(".correctincorrect").removeClass("hide");
    };
    
    ComponentAbstract.prototype.getOptions = function() {
    	return [];
    	
    };
    /*
     * @ p_score			: This could be a STRING, ARRAY or OBJECT.
     * @ p_selectedOptionID	: This could be a STRING, ARRAY or OBJECT. Example: String in case of MCQ, Array in case of Conversation
     */
    ComponentAbstract.prototype.updateScoreAndUserSelections = function(p_score, p_selectedOptionID) {
        //Logger.logDebug("ComponentAbstract.updateScoreAndUserSelections() ");
        var sfbType = this.oDataModel.getFeedbackType().toUpperCase();
        /*,
        sSelectedID			= p_oSelectedOption.getID(),
        nScore				= p_oSelectedOption.getScore();

        // ** Scoring
        switch(sfbType){
        case "PARAMETERBASEDFEEDBACK" :
        // ** Adding up the value to the current score
        this.oDataModel.updateScore(p_oSelectedOption.getParameters());
        break;
        default :
        // ** Adding up the value to the current score
        this.oDataModel.updateScore(p_score);
        // ** Adding up the value to the Score ARRAY
        this.oDataModel.updateUserScores(p_score);
        break;
        };*/

        // ** Adding up the value to the current score
        this.oDataModel.updateScore(p_score);
        this.oDataModel.updateUserScores(p_score);
        // ** Adding the selected item to the User Selections ARRAY
        this.oDataModel.updateUserSelections(p_selectedOptionID);
    };

    ComponentAbstract.prototype._activityCompleted = function() {
        //Logger.logDebug("ComponentAbstract._activityCompleted() | ");
        var oScope = this;
        //this.oDataModel.updateUserScores();
        if (this.oDataModel.getFeedbackType().toUpperCase().indexOf('PARAMETERBASED') != -1) {
            oFeedbackHistory = this.oDataModel.getFeedback(true);
        }
        //Logger.logDebug("ComponentAbstract._activityCompleted() | getUserScores = "+ this.oDataModel.getUserScores());
        if (this.oDataModel.displayTickCross() && (this.oDataModel.getTickCrossDisplayTrigger() === undefined || this.oDataModel.getTickCrossDisplayTrigger().toUpperCase() === "COMPLETE" || this.oDataModel.getTickCrossDisplayTrigger().toUpperCase() === "" )) {
            this.displayTickCross();
        }
		this.attempted = true;
        this.dispatchEvent('ACTIVITY_COMPLETE', {
            type : 'ACTIVITY_COMPLETE',
            target : oScope,
			scoringuid:this.oDataModel.getScoringUID(),
			trigger: this.getNextTrigger()
        });

    };

	/**
	 * this is a stub method to check if activity has trigger for next action
	 * Each activity will overright this implementation. And dispatch nessasary Event 
	 */
	ComponentAbstract.prototype.getNextTrigger				= function(){
		var trigger 			= this.oDataModel.oDataModel._trigger,
    	oTrigger;
    	if(trigger){
	    	oTrigger			= {target:trigger, optID:''};
    	}        
    	return oTrigger;
	};
    //Added by bharat
    ComponentAbstract.prototype.isAttemptsCompleted = function() {
        return this.oDataModel.isAttemptsCompleted();
    };

    ComponentAbstract.prototype.isSubmitEnabled = function() {
        return !this.$btnSubmit.hasClass('disabled');
    };
    ComponentAbstract.prototype.openPopup = function(p_sPopupID, p_sTitle, p_sContent, p_$returnFocusTo, p_sClassesToAdd, p_fCallback, p_aArgs) {
        //Logger.logDebug('PageAbstract.openPopup() | '+p_sPopupID, p_sTitle, p_sContent, p_$returnFocusTo);
        var sClass = p_sClassesToAdd || "";
        sClass += this.oDataModel.isCorrect() ? " correct " : " incorrect ", sClass += "attempt-" + this.oDataModel.getCurrentAttempt() + " ", sClass += this.oDataModel.getQuestionID();

        oPopup = PopupManager.openPopup(p_sPopupID, {
            txt_title : p_sTitle,
            txt_content : p_sContent
        }, p_$returnFocusTo, sClass);
        oPopup.addEventListener('POPUP_CLOSE', this.popupEventHandler);
        oPopup.addEventListener('POPUP_EVENT', this.popupEventHandler);
        if (p_fCallback) {
            oPopup.setCallback(this, p_fCallback, p_aArgs);
        }
        return oPopup;
    };

    ComponentAbstract.prototype.popupEventHandler = function(e) {
        var sEventType = e.type, oPopup = e.target, sPopupID = oPopup.getID();
        //Logger.logDebug('PageAbstract.popupEventHandler() | Event Type = '+sEventType+' : Popup ID = '+sPopupID+' : Event Src = '+e.eventSrc);

        if (sEventType === 'POPUP_EVENT' || sEventType === 'POPUP_CLOSE') {
            oPopup.removeEventListener('POPUP_CLOSE', this.popupEventHandler);
            oPopup.removeEventListener('POPUP_EVENT', this.popupEventHandler);
            //if (sEventType === 'POPUP_EVENT') {
                PopupManager.closePopup(sPopupID);
            //}
        }
    };

    ComponentAbstract.prototype.resetScore = function() {
    
        this.oDataModel.oScore.reset();
    };
    ComponentAbstract.prototype.resetAttemptNumber = function() {
        this.oDataModel.resetAttemptNumber();
    };

    ComponentAbstract.prototype.getScore = function() {
        return this.oDataModel.oScore;
    };
    ComponentAbstract.prototype.setMaxPossibleScore = function(p_nMaxPossibleScore) {
        this.oDataModel.setMaxPossibleScore(p_nMaxPossibleScore);
    };
    
    ComponentAbstract.prototype.getMaxPossibleScore = function() {
        return this.oDataModel.getMaxPossibleScore();
    };
    ComponentAbstract.prototype.getUserSelections = function() {
        return this.oDataModel.getUserSelections();
    };
     ComponentAbstract.prototype.isCorrect = function() {
        return this.oDataModel.isCorrect();
    };
    ComponentAbstract.prototype.updateAttempNumber = function() {
        this.oDataModel.updateAttempNumber();
    };

    ComponentAbstract.prototype._hasQuestionContainer = function($domActivity, sQuestionID) {
        if ($domActivity.length == 0) {
            Logger.logError('MCQGroup._populateLayout() | No element with Question ID "' + sQuestionID + '" found.');
        }
        if ($domActivity.length > 1) {
            Logger.logError('MCQGroup._populateLayout() | More than 1 element with Question ID "' + sQuestionID + '" found.');
        }
    };

    ComponentAbstract.prototype.getScoringUID = function() {
        return this.oDataModel.getScoringUID();
    };

    ComponentAbstract.prototype.getQuestionID = function() {
        return this.oDataModel.getQuestionID();
    };

    ComponentAbstract.prototype.getBookmark = function() {
        return this.oDataModel.getBookmark();
    };

    ComponentAbstract.prototype.getFeedback = function() {
        //Logger.logDebug("ComponentAbstract.processFeedbackPopup() | ");
        return this.oDataModel.getFeedback();
    };

    ComponentAbstract.prototype.processFeedbackPopup = function() {
        var oScope          = this,
            oFeedback       = this.getFeedback(),
            sFeedbackTitle  = oFeedback.getTitle(),
            sFeedback       = oFeedback.getContent(),
            sClassesToAdd   = oFeedback.getStyle(),
            sAudioID        = oFeedback.getAudioID(),
            oTransitionPopup,
            oEvent = {
                target              : oScope,
                popup               : oTransitionPopup
            };
        //Logger.logDebug("ComponentAbstract.init() | \n\tShowFeedbackPopup = "+this.oDataModel.isShowFeedbackPopup());
        if(this.oDataModel.isShowFeedbackPopup()){
            oTransitionPopup = this.openPopup('feedback', sFeedbackTitle, sFeedback, $('.btn-submit'), sClassesToAdd);
            if(sAudioID != undefined){
                AudioManager.playAudio(sAudioID);               
            }
            oTransitionPopup.setCallback(this, this.checkAndResetOptions , [{audioID: sAudioID}]);

        }else{
            this.checkAndResetOptions();
        }
        this.dispatchEvent('AFTER_ACTIVITY_POPUP', oEvent);
        
    };
    
    ComponentAbstract.prototype.getView = function() {
        return this.$domView;
    };

    ComponentAbstract.prototype.checkAndResetOptions = function(p_oArgs) {
        if(AudioManager.isPlaying() && AudioManager.getCurrentAudioID() === p_oArgs.audioID){
            AudioManager.stop();
        }

    };

    
    ComponentAbstract.prototype.hideAnswers = function(p_$domScope, p_sID) {
    	this.$domView.find(".correct").removeClass("correct");   
    	this.$domView.find(".incorrect").removeClass("incorrect");   
    	this.$domView.find(".correctincorrect").addClass("hide");   
    	
    };
    
    ComponentAbstract.prototype.getElementByID = function(p_$domScope, p_sID) {
        //Logger.logDebug('ComponentAbstract.getElementByID() | DOM Scope = '+p_$domScope+' : ID = '+p_sID);
        var $elem = (p_$domScope.attr('id') === p_sID) ? p_$domScope : p_$domScope.find('#' + p_sID);
        //Logger.logDebug('ComponentAbstract.getElementByID() | Element Length = '+$elem.length);
        if ($elem.length == 0) {
            Logger.logError('ComponentAbstract.getElementByID() | No Elements found with the name "' + p_sID + '"');
        }
        if ($elem.length > 1) {
            Logger.logWarn('ComponentAbstract.getElementByID() | More than 1 element has the same ID "' + p_sID + '"');
        }
        return $elem;
    };

    ComponentAbstract.prototype.getElementByClassName = function(p_$domScope, p_sClass) {
        if ( typeof p_$domScope.find !== 'function') {
            return;
        }
        $elems = p_$domScope.find('.' + p_sClass);
        //Logger.logDebug('ComponentAbstract.getElementByClassName() | Element Length = '+$elems.length);
        if ($elems.length == 0) {
            Logger.logError('ComponentAbstract.getElementByClassName() | No Elements found with the name "' + p_sClass + '"');
        }
        return $elems;
    };

    ComponentAbstract.prototype.isBtnActive = function(p_domBtn) {
        var isActive = ($(p_domBtn).hasClass('inactive') || $(p_domBtn).hasClass('disabled')) ? false : true;
        return isActive;
    };

    ComponentAbstract.prototype.sanitizeValue = function(p_sValue, p_sDefaults) {
        var sValue = p_sValue.split(' ').join(''), retVal;
        //Logger.logDebug('ComponentAbstract.sanitizeValue() | Value = '+p_sValue+' : Default = '+p_sDefaults);

        if (!sValue || sValue === '' || sValue === null || sValue === undefined) {
            // ** Value is Not Specified OR Undefined
            retVal = p_sDefaults;
        } else if (sValue.toUpperCase() === 'TRUE' || sValue.toUpperCase() === 'FALSE') {
            // ** Value is a Boolean
            retVal = (sValue.toUpperCase() === 'TRUE') ? true : false;
        } else if (!isNaN(Number(sValue))) {
            // ** Value is a Number
            retVal = Number(p_sValue);
        } else {
            // ** Its a String
            retVal = p_sValue;
        }
        return retVal;
    };

    ComponentAbstract.prototype.enableSubmit = function(p_bEnable) {
        this.dispatchEvent('SUBMIT_ENABLED', {type: 'SUBMIT_ENABLED', target: this , enabled:p_bEnable});
    };

    ComponentAbstract.prototype.enableReset = function(p_bEnable) { 
        if (p_bEnable) { 
            this.$btnReset.removeClass('disabled').attr({ 
                /* START - ARIA Implementation */ 
                'aria-disabled': false 
                        /* END - ARIA Implementation */ 
            }); 
            this.$btnReset.removeAttr("disabled");
        } else { 
            this.$btnReset.addClass('disabled').attr({ 
                /* START - ARIA Implementation */ 
                'aria-disabled': true 
                        /* END - ARIA Implementation */ 
            }); 
            this.$btnReset.attr("disabled", "true");
        } 
    };
    ComponentAbstract.prototype.hasLoaded = function() {
        return this.bLoaded;
    };
    
    /**
     * Check if object is valid DOM lengh. Found this solution on stack overflow;
     * Checks only jQuery object
     * @param {Object} jQueryObj
     */
    // ** TODO: Remove this method and use Globals.getElementByID method instead
    ComponentAbstract.prototype.isValidDomElement = function(jQueryObj) {
        //Logger.logDebug('ComponentAbstract.isValidDomElement | '+(jQueryObj.length > 0 ));
        return (jQueryObj.length > 0 );
    };

    ComponentAbstract.prototype.isArray = function(p_aValue) {
        var bIsArray = (p_aValue.length) ? true : false;
        return bIsArray;
    };

    ComponentAbstract.prototype.destroy = function() {
        if (!this.oDataModel.getScore().isScorable()) {
            this.oDataModel.getScore().reset();
            //Reset for onRevisit
        }
        this.oDataModel.destroy();
        this.$domView = null;
        this.oDataModel = null;
        this.$btnSubmit = null;
        this.bLoaded = null;
        EventDispatcher.prototype.destroy.call(this);
        this.prototype = null;
    };

    ComponentAbstract.prototype.toString = function() {
        return 'framework/activity/ComponentAbstract';
    };

    return ComponentAbstract;
});
