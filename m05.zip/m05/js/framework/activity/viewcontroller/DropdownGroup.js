define([ 
    'jquery', 
    'framework/utils/globals', 
    'framework/activity/viewcontroller/ComponentAbstract', 
    'framework/activity/model/DropdownGroupModel', 
    'framework/activity/viewcontroller/Dropdown', 
    'framework/utils/Logger' 
], function($, Globals, ComponentAbstract, DropdownGroupModel, Dropdown, Logger) { 

    function DropdownGroup() { 
        //Logger.logDebug('DropdownGroup.CONSTRUCTOR() '); 
        ComponentAbstract.call(this); 
        this.aDDList = []; 
 		this.DDhandleEvents = this._handleEvents.bind(this);
        return this; 
    } 

    DropdownGroup.prototype = Object.create(ComponentAbstract.prototype); 
    DropdownGroup.prototype.constructor = DropdownGroup; 

    DropdownGroup.prototype.init = function(p_$xmlActivityNode, p_$domView, p_sGUID, p_sScoringUID, p_bIsSimulation) { 
        //Logger.logDebug('DropdownGroup.init() '); 
        // ** Calling Super Class "init()" function 
        ComponentAbstract.prototype.init.call(this, p_$xmlActivityNode, p_$domView, p_sGUID, p_sScoringUID, p_bIsSimulation); 
    }; 

    DropdownGroup.prototype._createDataModel = function(p_xmlActivityNode) { 
        this.oDataModel = new DropdownGroupModel(p_xmlActivityNode,  this.sGUID, this.sScoringUID); 

        /*** Listener to the DATA MODEL can be added here to listen to Model updates ***/ 
        /*this.oDataModel.addEventListener('UPDATE', function(e){ 
         oScope.handleModelUpdates(e); 
         });*/ 
    }; 

    /*** Model updates Handler to be used if required ***/ 
    /*DropdownGroup.prototype.handleModelUpdates = function(e){ 
     
     };*/ 

    DropdownGroup.prototype._populateLayout = function() { 
        //Logger.logDebug("DropdownGroup._populateLayout() | "); 
        var oScope = this, 
                sQuestionID = this.oDataModel.getQuestionID(), 
                sOptnGrpsCntnrClass = this.oDataModel.getOptionGroupsContainerClass(), 
                aOptionGroups = this.oDataModel.getOptionGroup(), 
                $domActivity = this.getElementByID(this.$domView, sQuestionID), 
                $domOptnGrpList = null, 
                nMaxPossibleScore = 0; 

        // ** Check to make sure that an element with the specified Question ID exists in the DOM 
        this._hasQuestionContainer(this, $domActivity, sQuestionID); 
		
		this.bHasShowAns	= this.oDataModel.getConfig('hasShowAnswer')? (this.oDataModel.getConfig('hasShowAnswer') == "true") : false;
		this.bHasReset 		= this.oDataModel.getConfig('hasResetBtn')? (this.oDataModel.getConfig('hasResetBtn') == "true") : false;
        ///dropdown-groups-container 
        var $domOptnGrpsCntnr = this.getElementByClassName($domActivity, sOptnGrpsCntnrClass); 
        // ** Check to make sure that a Radio Group Container exists in the DOM to hold the Groups of Radio Button Containers 
        this._hasOptionGroupCotainer($domOptnGrpsCntnr, sOptnGrpsCntnrClass, sQuestionID); 

        /* START - ARIA Implementation */ 
        $domActivity.attr({ 
            'role': 'application', 
            'tabindex': -1 
        }); 
        /* END - ARIA Implementation */ 

        // ** Iterarating within the Option Group Node 
        for (var i = 0; i < aOptionGroups.length; i++) { 
            var oOptionGroupPointer = aOptionGroups[i], 
                    sOptnGrpID = 'DropdownGroup_' + oOptionGroupPointer._id, 
                    sOptnGrpClass = oOptionGroupPointer._class, 
                    sStmntClass = oOptionGroupPointer.pageText._class, 
                    sStmntTxt = oOptionGroupPointer.pageText.__cdata, 
                    $domOptnList = null, 
                    nMaxScore = 0, 
                    aOptionsList = [], 
                    // ** Custom Vars 
                    sStatementID = 'dropdown_' + (i + 1) + '_label'; 

            //refer to dropdown-container 
            if (!$domOptnGrpList) { 
                $domOptnGrpList = this.getElementByClassName($domOptnGrpsCntnr, sOptnGrpClass); 
                //Logger.logDebug("$domOptnGrpList"+JSON.stringify($domOptnGrpList ,null,4) ) 
                //Logger.logDebug('aOptionGroups.length '+aOptionGroups.length); 
                // ** Check if the number of XML nodes for Radio Containers are Equal to the Number of Radio Containers in the DOM 
                if (aOptionGroups.length != $domOptnGrpList.length) { 
                    Logger.logError('DropdownGroup._populateLayout() | Number of Dropdown Containers in the XML dont Match with the DOM'); 
                } 
            } 
            $domOptnGrpPointer = $($domOptnGrpList[i]); 

            //Statement 
            var $domOptnStmnt = this.getElementByClassName($domOptnGrpPointer, sStmntClass); 
            this._hasOptionStatement($domOptnStmnt, sStmntClass, i, sOptnGrpClass); 
            $domOptnStmnt.html(sStmntTxt).attr('id', sStatementID); 

            //DropDown Values..... 
            // ** Iterarating within the Option node for its text and parameters 
            for (var j = 0; j < oOptionGroupPointer.option.length; j++) { 
                var oOption = oOptionGroupPointer.option[j]; 
                oOption.sOptnID = oOption._id; 
                oOption.sOptnClass = oOption._class; 
                oOption.nOptnScore = Number(oOption._score); 
                oOption.aOptnParameters = oOption.parameter; 
                oOption.sOptnLblClass = oOption.pageText._class; 
                oOption.sOptnLblTxt = oOption.pageText.__cdata; 
                nMaxScore = Math.max(nMaxScore, oOption.nOptnScore), 
                        sOptnClass = oOption._class; 

                aOptionsList.push(oOption); 
            } 

            //Logger.logDebug("\tOptn Lbl Txt = "+aOptionsList[0].sOptnLblTxt); 

            var $domOptn = this.getElementByClassName($domOptnGrpPointer, sOptnClass), 
                    nTabIndex = (i + 1), 
                    nNumOfOptions = aOptionGroups.length; 
            $domOptn.attr({ 
                /* START - ARIA Implementation */ 
                'role': 'combobox', 
                'aria-labelledby': sStatementID, 
                /*'aria-activedescendant' : 'rg1-r4'*/ 
                'tabindex': nTabIndex, 
                /*'aria-readonly' : true, 
                 'aria-autocomplete' : 'none',*/ 
                'aria-posinset': (i + 1), 
                'aria-setsize': nNumOfOptions 
                        /* END - ARIA Implementation */ 
            }); 

            this._hasOptionContainer($domOptn, sOptnClass, i, sOptnGrpClass); 

            this.createDropdown($domOptn, sOptnGrpID, aOptionsList); 




            nMaxPossibleScore += nMaxScore; 
        } 

        this.oDataModel.setMaxPossibleScore(nMaxPossibleScore); 
        //Logger.logDebug('nMaxPossibleScore = '+this.nMaxPossibleScore); 
        var sSubmitID = sQuestionID + '_submit'; 
        this.$btnSubmit = $('#' + sSubmitID + '.btn-submit'); 
        this.$btnSubmit.addClass('btn disabled').attr({ 
            /* START - ARIA Implementation */ 
            'role': 'button', 
            /* END - ARIA Implementation */ 
            'tabindex': (nTabIndex + 1) 
        }).on('click', function(e) { 
            e.preventDefault(); 
            if (oScope.isBtnActive(this)) { 
                e.type = 'SUBMIT'; 
                oScope._handleEvents(e); 
            } 
        }); 
        this.enableSubmit(false); 
        
        
        this.$btnReset = this.$domView.find('.btn-reset').attr('id',this.getQuestionID() + '_reset');
        this.enableReset(false); 
        if(this.oDataModel.oDataModel._hasReset === "true"){
        	this.$btnReset.removeClass('hide');
        }
        this.$btnReset.click(function(e){
        	oScope.reset();
        });
        
        this.$btnReset = this.$domView.find('.btn-reset').addClass('hide');
		this.enableReset(false);
		if(this.$btnReset.length){
			this.$btnReset.attr('id',this.getQuestionID() + '_reset');
			if(this.bHasReset){
				this.$btnReset.click(function(e) {
					e.preventDefault();
					if (oScope.isBtnActive(this)) {
						e.type = 'RESET';
						oScope._handleEvents(e);
					}
				});
				this.$btnReset.removeClass('hide');
			}
		}
			
        this.$btnShowAns 	= this.$domView.find('.btn-show-ans');
		if(this.$btnShowAns.length){
			this.$btnShowAns.addClass('hide');
			this.$btnShowAns.attr('id',this.getQuestionID() + '_showAns');
			if(this.bHasShowAns){
				this.$btnShowAns.click(function(e) {
					e.preventDefault();
					if (oScope.isBtnActive(this)) {
						e.type = 'SHOW_ANSWER';
						oScope._handleEvents(e);
					}
				});
				this.$btnShowAns.removeClass('hide');
			}else{
				this.$btnShowAns.remove();
			}
		}
		
		this.$btnUserAns 		= this.$domView.find('.btn-show-my-ans');
		if(this.$btnUserAns.length){
			this.$btnUserAns.attr('id',this.getQuestionID() + '_myAns');
			this.$btnUserAns.addClass('hide');
			if(this.bHasShowAns){
				this.$btnUserAns.click(function(e) {
					e.preventDefault();
					if (oScope.isBtnActive(this)) {
						e.type = 'SHOW_USER_ANSWER';
						oScope._handleEvents(e);
					}
				});
			}else{
				this.$btnUserAns.remove();
			}
		}
		
        this.bLoaded = true; 
        this.dispatchEvent("ACTIVITY_LOADED", {target: this, type: 'ACTIVITY_LOADED', GUID: this.sGUID, eventID: this.sEventID, incidentID: this.sIncidentID}); 
    }; 

    DropdownGroup.prototype.createDropdown = function(p_domOptn, p_sOptnGrpID, p_aOptionsList) { 
        var oScope = this, 
                oDD = new Dropdown(p_domOptn, p_sOptnGrpID, p_aOptionsList); 

        oDD.addEventListener('OPTION_SELECT', this.DDhandleEvents); 

        this.aDDList.push(oDD); 
    }; 

    DropdownGroup.prototype._handleEvents = function(e) { 
        if (typeof e.preventDefault == 'function') { 
            e.preventDefault(); 
        } 
        var target = e.target, 
                currentTarget = e.currentTarget, 
                type = e.type; 

        Logger.logDebug('-------------------DropdownGroup._handleEvents() | type  = '+type); 

        switch (type) { 
            case 'OPTION_SELECT': 
                this._dispatchSelectEvent(e); 
                this._checkAndEnableSubmit(); 
                break; 
            case 'SUBMIT': 
                this._evaluate(); 
                break;
            case 'RESET' :
				this.reset();
				break;
            case 'SHOW_ANSWER' :
				this.showCorrectAnswer();
				this.$btnShowAns.addClass('hide');
				this.$btnUserAns.removeClass('hide');
				break;
			case 'SHOW_USER_ANSWER' :
				this.showUserAnswer();
				this.$btnUserAns.addClass('hide');
				this.$btnShowAns.removeClass('hide');
				this.dispatchEvent(type, oEvent);
				break;
				
        } 
    }; 

    DropdownGroup.prototype._dispatchSelectEvent = function(e) { 
        this.dispatchEvent('OPTION_SELECT', {type: 'OPTION_SELECT', target: e.target}); 
    }; 

    DropdownGroup.prototype._checkAndEnableSubmit = function(p_optionID) { 
        for (var i = 0; i < this.aDDList.length; i++) { 
            var oDD = this.aDDList[i]; 
            if (!oDD.getSelectedOption()) { 
                this.enableSubmit(false); 
                return; 
            } 
        } 
        this.enableSubmit(true); 
    }; 
   
    DropdownGroup.prototype._evaluate = function() { 
        //Logger.logDebug("MCQ._evaluate() | sTrigger = "+ sTrigger); 
        //Set UI for Tick cross 
        //this.oDataModel.setMaxPossibleScore(this.nMaxPossibleScore); 


        this.disableActivity(); 
        this.enableSubmit(false); 
        this.enableReset(true); 
        this.oDataModel.updateAttempNumber(); 
        this.updateScoreAndUserSelections(); 
        ComponentAbstract.prototype._evaluate.call(this);

    }; 

    DropdownGroup.prototype.updateScoreAndUserSelections = function() { 
        //Logger.logDebug("MCQ.updateScoreAndUserSelections() | "); 
        var sfbType = this.oDataModel.getFeedbackType().toUpperCase(); 
        for (var i = 0; i < this.aDDList.length; i++) { 
            var oToggleGrp = this.aDDList[i], 
                    aUserSelections = [oToggleGrp.getSelectedOption(), oToggleGrp.getGroupID()], 
                    score = (sfbType == "PARAMETETERBASEDFEEDBACK") ? oToggleGrp.getParameters() : oToggleGrp.getScore(); 
            ComponentAbstract.prototype.updateScoreAndUserSelections.call(this, score, aUserSelections); 
        } 

        oScope = this, 
                oEvent = { 
                    type: 'SCORE_UPDATE', 
                    target: oScope, 
                    preventDefault: false, 
                    callback: oScope.updateHistory, 
                    args: [] 
                }; 
		if(this.bHasShowAns && !this.isCorrect()){
			this.$btnShowAns.removeClass('disabled');
		}
        this.dispatchEvent('SCORE_UPDATE', oEvent); 
        if (!oEvent.preventDefault) { 
            this.updateHistory(); 
        } 
    }; 

    DropdownGroup.prototype.updateHistory = function() { 
        this.oDataModel.getFeedback(true); 
        var oScope = this, 
                oEvent = { 
                    type: 'HISTORY_UPDATE', 
                    target: oScope, 
                    preventDefault: false, 
                    callback: oScope.processFeedbackPopup, 
                    args: [] 
                }; 

        this.dispatchEvent('HISTORY_UPDATE', oEvent); 
        if (!oEvent.preventDefault) { 
            this.processFeedbackPopup(); 
        } 
    }; 


    DropdownGroup.prototype.displayTickCross = function() { 
        for (var i = 0; i < this.aDDList.length; i++) { 
            var oToggleGrp = this.aDDList[i], 
                    sfbType = this.oDataModel.getFeedbackType().toUpperCase(), 
                    score = (sfbType == "PARAMETETERBASEDFEEDBACK") ? oToggleGrp.getParameters() : oToggleGrp.getScore(); 
            sTextForTickCross = parseInt(score) > 0 ? "correct" : "incorrect"; 

            oToggleGrp.$domOption.parent().addClass("display-result " +sTextForTickCross); 
        } 
         
    }; 

    DropdownGroup.prototype.openFeedbackPopup = function(sFeedbackTitle, sFeedback) { 
        var oTransitionPopup = this.openPopup('feedback', sFeedbackTitle, sFeedback, $('.btn-submit')); 
        oTransitionPopup.setCallback(this, this.checkAndResetOptions); 
    }; 

    DropdownGroup.prototype.disable = function(p_optionID) { 
        for (var i = 0; i < this.aDDList.length; i++) { 
            var oDD = this.aDDList[i]; 
            oDD.enable(false); 
        } 
        this.enableSubmit(false); 
    }; 

    DropdownGroup.prototype.checkAndResetOptions = function(p_oPopup, p_oArgs) { 
        if (this.isAttemptsCompleted()) { 
            this.disableActivity(); 
            this._activityCompleted(); 
        } else { 
            this.resetOptions(); 
            this.resetScore(); 
           
        } 
         if(this.isCorrect()){
         	   this.enableReset(false);
         }else{
            this.enableReset(true);         	
         }
        ComponentAbstract.prototype.checkAndResetOptions.call(this, p_oArgs);
         
    }; 

    DropdownGroup.prototype.disableActivity = function() { 
        //Logger.logDebug('DropdownGroup.disableActivity'+ this.aDDList.length); 
        for (var i = 0; i < this.aDDList.length; i++) { 
            var oDD = this.aDDList[i]; 

            oDD.enable(false); 
            oDD.removeEventListener('OPTION_SELECT', this.DDhandleEvents); 
        } 
		
        this.enableSubmit(false); 
    }; 

    DropdownGroup.prototype.updateModelScore = function(p_nUserScore, p_aUserScore, p_aUserSelections) { 
        this.oDataModel.setScore(p_nUserScore); 
        this.oDataModel.setUserScores(p_aUserScore); 
        this.oDataModel.setUserSelections(p_aUserSelections); 
    }; 


    DropdownGroup.prototype.reset = function() { 
    	this.resetOptions();
    	this.resetScore();
    	this.resetAttemptNumber();
    	this.dispatchEvent('RESET', {type:'RESET', target:this});
    	this.enableReset(false);
    };

    DropdownGroup.prototype.resetOptions = function() { 
        //console.log("resetOptions" + this.aDDList.length); 
        //Logger.logDebug('Nehal DropdownGroup.resetOptions() | '); 
        for (var i = 0; i < this.aDDList.length; i++) { 
            var oDD = this.aDDList[i]; 
            oDD.reset();
            oDD.addEventListener('OPTION_SELECT', this.DDhandleEvents);  
        } 
        this.getView().find('.display-result').removeClass('correct incorrect');
        this.enableReset(false);
        this.enableSubmit(false);
        this.$btnShowAns.addClass('disabled hide'); 
        this.$btnUserAns.addClass('hide');
        if(this.bHasShowAns){
	        this.$btnShowAns.removeClass('hide'); 
        } 
    }; 

    DropdownGroup.prototype.enableSubmit = function(p_bEnable) { 
        if (p_bEnable) { 
            this.$btnSubmit.removeClass('disabled').attr({ 
                /* START - ARIA Implementation */ 
                'aria-disabled': false 
                        /* END - ARIA Implementation */ 
            }); 
            this.$btnSubmit.removeAttr("disabled");
        } else { 
            this.$btnSubmit.addClass('disabled').attr({ 
                /* START - ARIA Implementation */ 
                'aria-disabled': true 
                        /* END - ARIA Implementation */ 
            }); 
            this.$btnSubmit.attr("disabled", "true");
        } 
        ComponentAbstract.prototype.enableSubmit.call(this);
    };
     
   
     
    DropdownGroup.prototype.showCorrectAnswer = function(p_bEnable) { 
    	for (var i=0; i <  this.aDDList.length; i++) {
		   this.aDDList[i].showCorrectAnswer();
		};
		this.getView().find('.correctincorrect').addClass('hide');
    };
    DropdownGroup.prototype.showUserAnswer = function(p_bEnable) { 
    	for (var i=0; i <  this.aDDList.length; i++) {
		   this.aDDList[i].showUserAnswer();
		};
		this.getView().find('.correctincorrect').removeClass('hide');
    };

    DropdownGroup.prototype._hasOptionStatement = function($domOptnStmnt, sStmntClass, i, sOptnGrpClass) { 
        if ($domOptnStmnt.length == 0) { 
            Logger.logError('DropdownGroup._populateLayout() | No element with class "' + sStmntClass + '" found in the element number "' + (i + 1) + '" having class "' + sOptnGrpClass + '"'); 
        } 
        if ($domOptnStmnt.length > 1) { 
            Logger.logError('DropdownGroup._populateLayout() | More than 1 element with class "' + sStmntClass + '" found in the element number "' + (i + 1) + '" having class "' + sOptnGrpClass + '"'); 
        } 
    }; 

    DropdownGroup.prototype._hasOptionContainer = function($domOptn, sOptnClass, i, sOptnGrpClass) { 
        if ($domOptn.length == 0) { 
            Logger.logError('DropdownGroup._populateLayout() | No element with class "' + sOptnClass + '" found in the element number "' + (i + 1) + '" having class "' + sOptnGrpClass + '"'); 
        } 
        if ($domOptn.length > 1) { 
            Logger.logError('DropdownGroup._populateLayout() | More than 1 element with class "' + sOptnClass + '" found in the element number "' + (i + 1) + '" having class "' + sOptnGrpClass + '"'); 
        } 
    }; 

    DropdownGroup.prototype._hasOptionGroupCotainer = function($domOptnGrpsCntnr, sOptnGrpsCntnrClass, sQuestionID) { 
        if ($domOptnGrpsCntnr.length == 0) { 
            Logger.logError('DropdownGroup._populateLayout() | No element with class "' + sOptnGrpsCntnrClass + '" found in element "' + sQuestionID + '"'); 
        } 
        if ($domOptnGrpsCntnr.length > 1) { 
            Logger.logError('DropdownGroup._populateLayout() | More than 1 element with class "' + sOptnGrpsCntnrClass + '" found in element "' + sQuestionID + '"'); 
        } 
    }; 

    DropdownGroup.prototype.destroy = function($domOptnGrpsCntnr, sOptnGrpsCntnrClass, sQuestionID) { 
        var oScope = this; 
        this.$btnSubmit.off(); 
    }; 

    DropdownGroup.prototype.toString = function() { 
        return 'framework/activity/DropdownGroup'; 
    }; 

    return DropdownGroup; 
}); 
