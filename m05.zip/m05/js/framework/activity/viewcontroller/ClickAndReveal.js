define([
	'jquery',
	'framework/utils/globals',
	'framework/utils/EventDispatcher',
	'framework/utils/Logger'
], function($, Globals, EventDispatcher, Logger){
	function ClickAndReveal(){
		EventDispatcher.call(this);
		this.$domRef;
		this.nFadeInSpeed;
		this.bFadeClickable;
		this.nFadeOutSpeed;
		return this;
	}

	ClickAndReveal.prototype						= Object.create(EventDispatcher.prototype);
	ClickAndReveal.prototype.constructor			= ClickAndReveal;

	ClickAndReveal.prototype.init					= function(p_$domView, p_bFadeClickable, p_nFadeOutSpeed, p_nFadeInSpeed){
		var oScope			= this;
		this.$domRef		= p_$domView;
		this.bFadeClickable	= p_bFadeClickable || false;
		this.nFadeOutSpeed	= p_nFadeOutSpeed || 1000;
		this.nFadeInSpeed	= p_nFadeInSpeed || 1000;
		//Logger.logDebug('ClickAndReveal.init() '+this.$domRef.find('.tis-btn').length);

		this.$domRef.find('ul.click-and-reveal .tis-btn').each(function(index, element){
			var sAriaControls	= $(this).attr('data-controls');
			$(this).attr({
				'role'			: 'button',
				'aria-controls'	: sAriaControls,
				'tabindex'		: (index+1)
			});
			$('#'+sAriaControls).attr({
				'tabindex'			: '-1',
				'role'				: 'region',
				'aria-expanded'		: false
			});
			//Logger.logDebug('ClickAndReveal.init() | '+$('#'+sAriaControls).attr('id')+' :: Label = "'+$('#'+sAriaControls).attr('aria-label')+'"');
			if(!$('#'+sAriaControls).attr('aria-label') && $(this).text() !== ''){
				$('#'+sAriaControls).attr({
					'aria-labelledby'	: $(this).attr('id')
				});
			}
		}).on('click', function(e){
			if(!$(this).hasClass('inactive') && !$(this).hasClass('disabled')){
				this.blur();
				oScope.handleEvents(e);
			}
		}).on('keydown', function(e){
			// Trigger the click event from the keyboard
			var code = e.which;
			// 13 = Return, 32 = Space
			if ((code === 13) || (code === 32)) {
				$(this).click();
			}
		});

		/*this.$domRef.find('ul.click-and-reveal .tis-btn').each(function(index, elem) {
		  //Logger.logDebug('##### '+elem.tagName);
		});*/
	};

	ClickAndReveal.prototype.handleEvents			= function(e){
		//Logger.logDebug('ClickAndReveal.handleEvents() | '+e.target.getAttribute('id')+' : '+e.currentTarget.getAttribute('id')+' : isDefaultPrevented = '+e.isDefaultPrevented());
		this.dispatchEvent('CLICK', {target:this, oEvent:e});
		//Logger.logDebug('ClickAndReveal.handleEvents() | isDefaultPrevented = '+e.isDefaultPrevented());
		if(!e.isDefaultPrevented()){
			var $target				= $(e.target);
				$elemToFadeIn		= $('#'+$target.attr('data-controls'));

			$target.removeClass('tis-btn').addClass('selected').attr({
				'aria-disabled' : 'true'
			}).removeAttr('aria-role').removeAttr('role');
			$elemToFadeIn.fadeIn(this.nFadeInSpeed).attr({'aria-expanded'		: true}).focus();
			if(this.bFadeClickable){
				$target.fadeOut(this.nFadeOutSpeed);
			}
		}
	};

	ClickAndReveal.prototype.getButtonList			= function(e){
		//Logger.logDebug('ClickAndReveal.getButtonList() '+this.$domRef.find('.tis-btn').length);
		return this.$domRef.find('.tis-btn');
	};

	ClickAndReveal.prototype.destroy				= function(e){
		//Logger.logDebug('ClickAndReveal.destroy() | ');
		var oScope	= this;
		this.$domRef.find('ul.click-and-reveal').off('click', 'tis-btn', function(e){
			oScope.handleEvents(e);
		});
		this.$domRef			= null;
		this.nFadeInSpeed		= null;
		this.bFadeClickable		= null;
		this.nFadeOutSpeed		= null;
	};

	return ClickAndReveal;
});
