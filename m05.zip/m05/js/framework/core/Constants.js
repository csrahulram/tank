define([], function() {
	return {
		CONFIGXMLURL:'xml/course_config.xml'
	};
});