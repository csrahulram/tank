define([
	'jquery',
	'framework/utils/Logger'
], function($, Logger){

	function CWModel(p_xmlnodeCW, p_sGUID, p_sParentCWGUID, p_oParentCW){
		var $xmlnodeCW = $(p_xmlnodeCW);
		this.sCWID = $xmlnodeCW.attr('data');
		this.sHierarchyLevel = $xmlnodeCW.attr('hierarchyLevel');
		this.sCWLabel = $xmlnodeCW.attr('label');
                if(this.sCWLabel=="Assessment")
                {
			this.sCWRandomization=$xmlnodeCW.attr('randomization');
			if(typeof $xmlnodeCW.attr('totalDisplayPages') != "undefined")
				this.sCWPickQuestions=$xmlnodeCW.attr('totalDisplayPages');
			this.sCWPassPer=$xmlnodeCW.attr('pasPer');
			this.sCWPagesFromStart=$xmlnodeCW.attr('pagesFromStart');
			this.sCWPagesFromEnd=$xmlnodeCW.attr('pagesFromEnd');
                }
		this.nCWStatus = 0; /*0=not visited | 1=visited | 2=completed*/
		this.sParentCWGUID = p_sParentCWGUID;
		this.oParentCW = p_oParentCW;
		this.aChildPages = [];
		/*this.aChildCW = [];*/
		this.sGUID = p_sGUID;

		Logger.logDebug('CWModel.CONSTRUCTOR() | CWID = '+this.sCWID+' : Label = '+this.sCWLabel+' : PARENT = '+p_sParentCWGUID+' : GUID = '+this.sGUID);
		return this;
	}

	CWModel.prototype = {
		constructor:CWModel,
		toString:function(){
			return "framework.model.CWModel";
		},
		getCWTotalPages:function(){
			return this.aChildPages.length;
		},
		getCWID:function (){
			return this.sCWID;
		},
		getGUID:function(){
			return this.sGUID;
		},
		getCWStatus:function(){return this.nCWStatus;},
		setCWStatus:function(p_nCWStatus){
			if(this.nCWStatus!=2)
				this.nCWStatus = p_nCWStatus;
		},
		getParentCWGUID:function(){
			return this.sParentCWGUID;
		},
		getParentCW:function(){
			return this.oParentCW;
		},
		getHierarchyLevel:function(){
			return this.sHierarchyLevel;
		},
		getCWLabel:function(){
			return this.sCWLabel;
		},
		getChildPages:function(){
			return this.aChildPages;
		},
		
		//cdcd
		/*getCurrentCWLabel:function(){
			return this.oParentCW;
		}*/
		//cdcd
		
		addChildPages:function(argNewVal){
			this.aChildPages.push(argNewVal);
		/*},
		getChildCW:function(){
			return this.aChildCW;
		},
		setChildCW:function(argNewVal){
			this.aChildCW.push(argNewVal);*/
		}
	};

	return CWModel;
});