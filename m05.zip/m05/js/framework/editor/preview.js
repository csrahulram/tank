define([
	'jquery'
	],
	function($){
	var Preview 	= function(){
		
	};
	
	
    
    Preview.prototype.init = function(p_elem){
    	var $content 	=$(p_elem).find('*[id]');
    	$content.each(function(index, elem){
    		var sId			= $(elem).attr("id");
    		var sContent	= $(elem).text();
    		var tool = $('<span class="editor-tool"><a href="#" class="txt-edit" title="text edit">t</a></span>');
    		tool.find('.txt-edit').click(function(e){
    			e.preventDefault();
    			var txt = $(this).parent().text();
    			var input	= $('<div class="edit-box"><textarea id="edit_'+sId +'" class="txt-area">'+sContent+'</textarea></div>');
    			var $submit	= $('<button id="edit_submit" class="btn-sprite btn-small">Submit</buttton>');
    			input.append($submit);
    			$(elem).append(input);
    		});
    		$(elem).append(tool);
    	});
    	console.log('elements with id attribute found - '+$content.length); 
    };
    

	return Preview;
});
