define([
	'framework/utils/Logger'
], function(Logger){
	function EventObject(p_sType,p_oTarget,p_oCurrentTarget,p_oData){
		//EventDispatcher.call(this);
		this.stype				= p_sType;
		this.oTarget			= p_oTarget;
		this.oCurrentTarget 	= p_oCurrentTarget;
		this.oData				= p_oData;
		this.bDefaultPrevented	= false;
		return this;
	}

	//EventObject.prototype								= Object.create(EventDispatcher.prototype);
	//EventObject.prototype.constructor					= EventObject;
	
	EventObject.prototype.defaultPrevented				= function(p_bFlag){
		if(p_bFlag === null){return this.bDefaultPrevented;}
		this.bDefaultPrevented = p_bFlag;
	};
	
	return EventObject;
});